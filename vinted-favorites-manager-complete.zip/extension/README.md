# 🎯 Vinted Favorites Manager - Extension Chrome

**Une extension Chrome simple et puissante pour gérer vos favoris Vinted**

---

## 🚀 Installation rapide

### 1️⃣ Préparer l'extension

- Télécharge ce dossier `extension/`
- Assure-toi qu'il contient :
  - `manifest.json`
  - `content-script.js`
  - `popup.html`
  - `images/` (dossier avec les icônes)

### 2️⃣ Activer le Mode Développeur Chrome

1. Ouvre Chrome et va sur `chrome://extensions/`
2. En haut à droite, active le **Mode de développeur**
3. Tu dois voir 3 boutons : "Charger l'extension non empaquetée", etc.

### 3️⃣ Charger l'extension

1. Clique sur **"Charger l'extension non empaquetée"**
2. Sélectionne le dossier `extension/` de ce projet
3. Voilà! L'extension est installée! ✅

### 4️⃣ Vérifier l'installation

- Tu dois voir l'icône de l'extension en haut à droite de Chrome
- Va sur https://www.vinted.fr/member/items/favourite_list
- Un bouton rouge **"🎯 Gérer les articles vendus"** doit apparaître en haut à droite

---

## 📖 Comment utiliser

### **Utilisation basique**

1. **Va sur tes favoris Vinted**
   ```
   https://www.vinted.fr/member/items/favourite_list
   ```

2. **Clique le bouton rouge** qui apparaît en haut à droite
   - Bouton : "🎯 Gérer les articles vendus"

3. **Attends le chargement** (10-15 secondes)
   - L'extension scroll automatiquement jusqu'à charger TOUS tes favoris

4. **Sélectionne les articles**
   - ✅ Tout sélectionner
   - ❌ Tout désélectionner
   - ☑️ Cocher individuellement

5. **Supprime!**
   - Clique le gros bouton rouge "🗑️ Supprimer la sélection"
   - Confirme quand on te le demande
   - C'est fait! La page se recharge.

---

## ⚙️ Structure du dossier

```
extension/
├── manifest.json          # Configuration de l'extension
├── content-script.js      # Le code qui s'exécute sur Vinted
├── popup.html             # La popup de l'extension
└── images/                # Les icônes
    ├── icon-16.png
    ├── icon-48.png
    └── icon-128.png
```

---

## 🎯 Ce qui se passe techniquement

### manifest.json
- Définit le nom, la version, les permissions de l'extension
- Dit à Chrome de charger `content-script.js` sur Vinted
- Définit l'icône et la popup

### content-script.js
- S'exécute automatiquement quand tu es sur la page des favoris
- Ajoute un bouton en haut à droite
- Quand tu cliques, lance le gestionnaire de favoris

### popup.html
- C'est la petite fenêtre qui s'ouvre quand tu cliques l'icône de l'extension
- Affiche les instructions et les boutons utiles

---

## 🔧 Personnalisation

### Changer la couleur du bouton

Dans `content-script.js`, cherche :
```javascript
btn.style.cssText = `
  background: linear-gradient(135deg, #ff4444 0%, #cc0000 100%);
```

Change `#ff4444` et `#cc0000` par tes couleurs préférées.

### Changer le texte du bouton

Cherche :
```javascript
btn.innerHTML = '🎯 Gérer les articles vendus';
```

Et remplace le texte.

### Ajouter tes propres icônes

1. Crée des images PNG 16x16, 48x48, 128x128
2. Mets-les dans le dossier `images/`
3. Renomme-les : `icon-16.png`, `icon-48.png`, `icon-128.png`

---

## ⚠️ Limitations

### L'extension ne fonctionne que sur:
- 🇫🇷 vinted.fr
- 🇬🇧 vinted.com
- 🇩🇪 vinted.de
- 🇪🇸 vinted.es
- 🇮🇹 vinted.it
- 🇳🇱 vinted.nl
- 🇧🇪 vinted.be
- 🇵🇱 vinted.pl
- 🇸🇪 vinted.se
- 🇩🇰 vinted.dk
- 🇨🇿 vinted.cz
- 🇱🇹 vinted.lt

### Elle ne marche que sur:
- ✅ La page des favoris (`/member/items/favourite_list`)
- ❌ Pas sur les autres pages de Vinted

---

## 🐛 Dépannage

### Le bouton n'apparaît pas
- Assure-toi d'être sur la page des favoris
- Recharge la page (F5)
- Désactive les adblockers temporairement
- Vérifie que l'extension est bien activée (`chrome://extensions/`)

### L'extension ne détecte aucun article vendu
- Il n'y a peut-être aucun article vendu dans tes favoris! ✅
- Ou la structure HTML de Vinted a changé (contacte le dev)

### La suppression ne marche pas
- Vinted a peut-être changé son interface
- Recharge la page et réessaye
- Contacte le développeur

### Je ne peux pas installer l'extension
- Chrome ne permet les extensions non empaquetées qu'en Mode Développeur
- Assure-toi d'avoir activé le Mode Développeur dans `chrome://extensions/`
- Certaines versions de Chrome ont des restrictions. Essaye avec Chrome Canary ou Developer

---

## 📦 Empaqueter l'extension (optionnel)

Si tu veux la partager ou la mettre sur le Chrome Web Store:

1. Va sur `chrome://extensions/`
2. Clique "Empaqueter l'extension"
3. Sélectionne le dossier `extension/`
4. Chrome crée un fichier `.crx` (l'extension empaquetée)

---

## 🆘 Support

Des problèmes? Des idées?

- Crée une **issue** sur GitHub
- Envoie un email au développeur
- Décris le problème au maximum!

---

## 📋 Changelog

### v1.0.0
- ✨ Première version
- 🚀 Détection automatique des articles vendus
- 🎨 Interface belle et intuitive
- ✅ Suppression en masse
- 🔄 Chargement de tous les favoris (scroll infini)

---

## 📄 Licence

Libre d'utilisation et de modification.

---

**Bonne gestion de tes favoris! 🚀**
