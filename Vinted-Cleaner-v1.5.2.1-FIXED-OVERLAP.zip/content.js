
console.log('💖 Vinted Cleaner v1.5.2 - loaded');

let autoFavStopRequested = false;
let isAutoFavRunning = false;

let vcLauncherClosedUntil = 0;
function isBigPanelOpen(){
  return document.getElementById('vinted-dressing-panel') || document.getElementById('vinted-ultra-panel') || document.getElementById('af-panel') || document.getElementById('vinted-ultra-bar');
}
function injectLauncher(){
  try{
    if(!document.body) return;
    if(Date.now() < vcLauncherClosedUntil) return;
    if(isBigPanelOpen()){
      const existing = document.getElementById('vinted-cleaner-launcher');
      if(existing) existing.style.display='none';
      return;
    }
    const existing = document.getElementById('vinted-cleaner-launcher');
    if(existing){
      existing.style.display='flex';
      return;
    }
    const div=document.createElement('div');
    div.id='vinted-cleaner-launcher';
    div.style.cssText='position:fixed;bottom:20px;right:20px;z-index:999998;background:#111;color:white;padding:12px 16px;border-radius:12px;border:2px solid #ff4444;box-shadow:0 8px 32px rgba(0,0,0,0.6);display:flex;flex-direction:column;gap:8px;font-family:sans-serif;min-width:220px';
    div.innerHTML=`
      <div style="display:flex;justify-content:space-between;align-items:center;width:100%">
        <span style="font-weight:bold;font-size:13px">💖 Cleaner v1.5.2</span>
        <button id="vc-close" style="background:#222;color:#888;padding:4px 8px;border:none;border-radius:6px;cursor:pointer">✕</button>
      </div>
      <div style="display:flex;gap:6px">
        <button id="vc-sold" style="flex:1;background:#ff4444;color:white;padding:8px 10px;border:none;border-radius:6px;font-weight:bold;cursor:pointer;font-size:12px">🔴 Vendus</button>
        <button id="vc-dress" style="flex:1;background:#0074de;color:white;padding:8px 10px;border:none;border-radius:6px;font-weight:bold;cursor:pointer;font-size:12px">💙 Dressing</button>
      </div>
      <div style="border-top:1px solid #333;padding-top:8px;margin-top:2px">
        <div style="font-size:11px;color:#aaa;margin-bottom:4px;font-weight:bold">❤️ AUTO-FAV Dressing (Clemz-like)</div>
        <div style="display:flex;gap:6px;align-items:center">
          <input id="vc-fav-count" type="number" value="30" min="1" max="200" style="width:60px;background:#222;color:white;border:1px solid #444;border-radius:6px;padding:6px;text-align:center;font-weight:bold">
          <button id="vc-fav" style="flex:1;background:#ff2e63;color:white;padding:8px 10px;border:none;border-radius:6px;font-weight:bold;cursor:pointer;font-size:12px">❤️ Auto-Fav N</button>
        </div>
        <div id="vc-fav-progress" style="display:none;margin-top:6px;font-size:11px;color:#ff8fab;text-align:center"></div>
      </div>
    `;
    document.body.appendChild(div);
    div.querySelector('#vc-sold').onclick=()=>{ runUltraScan(); };
    div.querySelector('#vc-dress').onclick=()=>{ runCleanDressing(); };
    div.querySelector('#vc-fav').onclick=()=>{
      const n = parseInt(div.querySelector('#vc-fav-count').value) || 30;
      runAutoFavDressing(n);
    };
    div.querySelector('#vc-close').onclick=()=>{ vcLauncherClosedUntil = Date.now() + 60000; div.remove(); console.log('Launcher fermé pour 60s'); };
  }catch(e){ console.error('inject fail', e); }
}

// --- ULTRA SCAN VENDUS (inchangé) ---
async function runUltraScan(){
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  console.log('🚀 ULTRA SCAN 2420 - Démarrage');
  let bar=document.createElement('div');
  bar.id='vinted-ultra-bar';
  bar.style.cssText='position:fixed;top:0;left:0;width:100%;background:#111;color:white;padding:10px;text-align:center;z-index:9999999;font-family:sans-serif;font-size:14px;border-bottom:3px solid #ff4444';
  bar.innerHTML=`<div>📦 SCAN ULTRA en cours... <span id="ultra-count">0</span> favs chargés | <span id="ultra-sold">0</span> vendus trouvés</div><div style="height:4px;background:#333;margin-top:6px"><div id="ultra-progress" style="height:100%;width:0%;background:#ff4444;transition:width 0.3s"></div></div>`;
  try{ document.body.appendChild(bar); }catch(e){}

  let lastCount=0, stable=0;
  let allSoldData=[];
  const MAX_FAVS=3000;
  const STABLE_LIMIT=10;

  while(stable < STABLE_LIMIT && lastCount < MAX_FAVS){
    const items=document.querySelectorAll('[data-testid="grid-item"]');
    const currentCount=items.length;
    const countEl=document.getElementById('ultra-count');
    const soldEl=document.getElementById('ultra-sold');
    const progEl=document.getElementById('ultra-progress');
    if(countEl) countEl.textContent=currentCount;
    if(progEl) progEl.style.width=`${Math.min(99, (currentCount/2420)*100)}%`;

    items.forEach((gridItem)=>{
      if(gridItem.dataset.scanned) return;
      gridItem.dataset.scanned="1";
      try{
        const statusText=gridItem.querySelector('[data-testid*="status-text"]');
        if(statusText && ['vendu','vendido','sold','venduto','verkauft'].includes(statusText.textContent.trim().toLowerCase())){
          const titleEl=gridItem.querySelector('[data-testid*="description-title"]');
          const title=titleEl?titleEl.textContent.trim().substring(0,40):`Article`;
          const favBtn=gridItem.querySelector('button[data-testid*="favourite"]')||gridItem.querySelector('button[data-testid*="favorite"]')||gridItem.querySelector('button[data-testid*="item-favourite-button"]');
          if(favBtn){
            allSoldData.push({title,favBtn,gridItem});
            if(soldEl) soldEl.textContent=allSoldData.length;
            try{ gridItem.style.outline='3px solid #ff4444'; }catch(e){}
          }
        }
      }catch(e){}
    });

    if(items.length>0){
      try{ items[items.length-1].scrollIntoView({block:'end'}); }catch(e){}
      await sleep(200);
      try{ window.scrollBy(0,300); }catch(e){}
    }else{
      try{ window.scrollTo(0,document.body.scrollHeight); }catch(e){}
    }
    await sleep(1100);
    const newCount=document.querySelectorAll('[data-testid="grid-item"]').length;
    if(newCount===lastCount){ stable++; } else { stable=0; }
    lastCount=newCount;
    if(newCount>=MAX_FAVS) break;
  }

  const progEl=document.getElementById('ultra-progress');
  if(progEl) progEl.style.width='100%';
  const barEl=document.getElementById('vinted-ultra-bar');
  if(barEl) barEl.innerHTML=`✅ Scan fini: ${lastCount} favs parcourus, ${allSoldData.length} vendus trouvés`;
  console.log(`✅ FIN SCAN: ${lastCount} favs, ${allSoldData.length} vendus`);
  if(allSoldData.length===0){
    alert(`✅ Aucun vendu sur ${lastCount} favs scannés !`);
    if(barEl) setTimeout(()=>barEl.remove(),4000);
    return;
  }
  // panel vendus
  if(document.getElementById('vinted-ultra-panel')) document.getElementById('vinted-ultra-panel').remove();
  const panel=document.createElement('div'); panel.id='vinted-ultra-panel';
  panel.style.cssText='position:fixed;bottom:20px;right:20px;background:#1e1e1e;color:white;padding:18px;border-radius:12px;z-index:1000000;width:380px;border:2px solid #ff4444;font-family:sans-serif';
  panel.innerHTML=`<h3 style="margin:0 0 10px">🔴 ${allSoldData.length} vendus trouvés</h3><div id="vlist" style="max-height:300px;overflow-y:auto;margin-bottom:10px"></div><div style="display:flex;gap:6px;margin-bottom:10px"><button id="vselAll" style="flex:1;padding:8px;background:#4CAF50;color:white;border:none;border-radius:6px">✅ Tout</button><button id="vdesAll" style="flex:1;padding:8px;background:#555;color:white;border:none;border-radius:6px">❌ Aucun</button></div><button id="vdel" style="width:100%;padding:12px;background:#ff4444;color:white;border:none;border-radius:8px;font-weight:bold">Retirer la sélection</button><button id="vclose" style="width:100%;margin-top:8px;background:transparent;color:#888;border:none">Fermer</button>`;
  document.body.appendChild(panel);
  const vlist=panel.querySelector('#vlist'); const checks=[];
  allSoldData.forEach((o,i)=>{
    const row=document.createElement('label'); row.style.cssText='display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #333;font-size:12px;cursor:pointer';
    row.innerHTML=`<input type="checkbox" checked><span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${o.title}</span>`;
    vlist.appendChild(row); checks.push({cb:row.querySelector('input'), favBtn:o.favBtn, gridItem:o.gridItem});
  });
  panel.querySelector('#vselAll').onclick=()=>checks.forEach(c=>c.cb.checked=true);
  panel.querySelector('#vdesAll').onclick=()=>checks.forEach(c=>c.cb.checked=false);
  panel.querySelector('#vclose').onclick=()=>{ panel.remove(); vcLauncherClosedUntil=0; setTimeout(()=>injectLauncher(), 500); };
  panel.querySelector('#vdel').onclick=async()=>{
    const sel=checks.filter(c=>c.cb.checked); if(!sel.length) return alert('Vide'); if(!confirm(`Retirer ${sel.length} vendus?`)) return;
    for(let i=0;i<sel.length;i++){ sel[i].gridItem.style.opacity='0.3'; sel[i].favBtn.click(); await sleep(700); }
    alert(`✅ ${sel.length} retirés`); location.reload();
  };
  function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }
}

// --- FIX V1.5.2 : CLEAN DRESSING AVEC PRE-SCROLL COMPLET (Issue #1) ---
async function runCleanDressing(){
  console.log('👕 Dressing Cleaner V1.5.2 - Démarrage...');
  const sleep = ms => new Promise(r=>setTimeout(r,ms));

  // FIX #1 : Pre-scroll complet
  let loadBar = document.createElement('div');
  loadBar.style.cssText='position:fixed;top:0;left:0;width:100%;background:#0074de;color:white;padding:8px;text-align:center;z-index:9999999;font-family:sans-serif;font-size:13px';
  loadBar.textContent='⏳ V1.5.2: Chargement complet du dressing pour voir tous les favs...';
  document.body.appendChild(loadBar);

  let lastHeight=0,noChange=0;
  for(let i=0;i<150 && noChange<6;i++){
    window.scrollTo(0, document.body.scrollHeight);
    await sleep(800);
    window.scrollTo(0, document.body.scrollHeight - 800);
    await sleep(200);
    window.scrollTo(0, document.body.scrollHeight);
    await sleep(400);
    const h=document.body.scrollHeight;
    if(h===lastHeight){noChange++;} else {noChange=0;}
    lastHeight=h;
    loadBar.textContent=`⏳ Chargement... ${i+1} scrolls - ${document.querySelectorAll('[data-testid="grid-item"]').length} articles`;
    if(noChange>5) break;
  }
  window.scrollTo(0,0);
  await sleep(700);
  loadBar.remove();

  const allItems=document.querySelectorAll('[data-testid="grid-item"]');
  const favItems=[];
  allItems.forEach(item=>{
    const favBtn = item.querySelector('button[data-testid="favourite-button"]') ||
                   item.querySelector('button[data-testid="favorite-button"]') ||
                   item.querySelector('button[data-testid="item-favourite-button"]') ||
                   item.querySelector('button[aria-label*="favoris"]') ||
                   item.querySelector('button[aria-label*="favourite"]') ||
                   item.querySelector('button[aria-label*="favorite"]');
    if(!favBtn) return;
    const ariaLabel = (favBtn.getAttribute('aria-label')||'').toLowerCase();
    const pressed = favBtn.getAttribute('aria-pressed');
    const isFav = ariaLabel.includes('retirer') || ariaLabel.includes('remove') || ariaLabel.includes('quitar') || ariaLabel.includes('rimuovi') || ariaLabel.includes('entfernen') || pressed === 'true';
    if(isFav){ favItems.push({item, favBtn}); }
  });

  console.log(`❤️ Trouvés: ${favItems.length} sur ${allItems.length} scannés`);
  if(favItems.length===0){ alert(`✅ Aucun fav de ce dressing dans tes favoris\n\nJ'ai scanné ${allItems.length} articles après chargement complet (Fix v1.5.2).`); return; }

  favItems.forEach(({item})=>{
    item.style.outline='4px solid #0074de'; item.style.outlineOffset='2px'; item.style.position='relative';
    const b=document.createElement('div'); b.textContent='💙 DANS TES FAVS'; b.style.cssText='position:absolute;top:8px;left:8px;background:#0074de;color:white;padding:5px 10px;border-radius:20px;font-weight:bold;font-size:11px;z-index:50';
    item.appendChild(b);
  });

  if(document.getElementById('vinted-dressing-panel')) document.getElementById('vinted-dressing-panel').remove();
  const panel=document.createElement('div'); panel.id='vinted-dressing-panel';
  panel.style.cssText='position:fixed;bottom:20px;right:20px;background:#1e1e1e;color:white;padding:18px;border-radius:12px;z-index:1000000;width:360px;border:2px solid #0074de;font-family:sans-serif';
  panel.innerHTML=`<h3 style="margin:0 0 10px">💔 ${favItems.length} favs dans ce dressing<br><small style="font-weight:normal;color:#aaa">sur ${allItems.length} articles scannés (v1.5.2)</small></h3><div id="vlist" style="max-height:300px;overflow-y:auto;margin-bottom:10px"></div><div style="display:flex;gap:6px;margin-bottom:10px"><button id="vselAll" style="flex:1;padding:8px;background:#4CAF50;color:white;border:none;border-radius:6px">✅ Tout</button><button id="vdesAll" style="flex:1;padding:8px;background:#555;color:white;border:none;border-radius:6px">❌ Aucun</button></div><button id="vdel" style="width:100%;padding:12px;background:#0074de;color:white;border:none;border-radius:8px;font-weight:bold">Retirer la sélection</button><button id="vclose" style="width:100%;margin-top:8px;background:transparent;color:#888;border:none">Fermer</button>`;
  document.body.appendChild(panel);
  const vlist=panel.querySelector('#vlist'); const checks=[];
  favItems.forEach((o,i)=>{
    const title=(o.item.querySelector('[data-testid*="description-title"]')?.textContent||`Article ${i+1}`).slice(0,35);
    const row=document.createElement('label'); row.style.cssText='display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #333;font-size:12px;cursor:pointer';
    row.innerHTML=`<input type="checkbox" checked><span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${title}</span>`;
    vlist.appendChild(row); checks.push({cb:row.querySelector('input'), favBtn:o.favBtn, item:o.item});
  });
  panel.querySelector('#vselAll').onclick=()=>checks.forEach(c=>c.cb.checked=true);
  panel.querySelector('#vdesAll').onclick=()=>checks.forEach(c=>c.cb.checked=false);
  panel.querySelector('#vclose').onclick=()=>{ panel.remove(); vcLauncherClosedUntil=0; setTimeout(()=>injectLauncher(), 500); };
  panel.querySelector('#vdel').onclick=async()=>{
    const sel=checks.filter(c=>c.cb.checked); if(!sel.length) return alert('Vide'); if(!confirm(`Retirer ${sel.length} favs?`)) return;
    for(let i=0;i<sel.length;i++){ sel[i].item.style.opacity='0.3'; sel[i].favBtn.click(); await sleep(700); }
    alert(`✅ ${sel.length} retirés sur ${favItems.length} trouvés`); location.reload();
  };
}

// --- FIX V1.5.2 : AUTO-FAV AVEC PRE-SCROLL + MESSAGE 3/10 (Issue #1 + #2) ---
async function runAutoFavDressing(N){
  N = parseInt(N) || 30;
  if(isAutoFavRunning){ alert('Déjà en cours !'); return; }
  isAutoFavRunning = true;
  autoFavStopRequested = false;
  const sleep = ms => new Promise(r=>setTimeout(r,ms));

  if(document.getElementById('af-panel')) document.getElementById('af-panel').remove();
  const panel=document.createElement('div'); panel.id='af-panel';
  panel.style.cssText='position:fixed;bottom:20px;right:20px;background:#1e1e1e;color:white;padding:18px;border-radius:12px;z-index:1000000;width:380px;border:2px solid #ff2e63;font-family:sans-serif';
  panel.innerHTML=`
    <h3 style="margin:0 0 10px">❤️ Auto-Fav v1.5.2 - ${N} demandés</h3>
    <div style="margin-bottom:8px">Progression: <span id="af-count">0</span> / ${N}</div>
    <div style="height:6px;background:#333;border-radius:3px;margin-bottom:10px"><div id="af-bar" style="height:100%;width:0%;background:#ff2e63;border-radius:3px;transition:width 0.3s"></div></div>
    <div id="af-status" style="font-size:11px;color:#aaa;margin-bottom:6px">Chargement initial du dressing...</div>
    <div id="af-log" style="max-height:180px;overflow-y:auto;background:#111;padding:8px;border-radius:6px;font-size:11px;border:1px solid #333;margin-bottom:10px"></div>
    <button id="af-stop" style="width:100%;padding:12px;background:#333;color:white;border:1px solid #555;border-radius:8px;font-weight:bold;cursor:pointer">⏹️ Stop</button>
  `;
  document.body.appendChild(panel);
  const countEl = panel.querySelector('#af-count');
  const barEl = panel.querySelector('#af-bar');
  const logEl = panel.querySelector('#af-log');
  const statusEl = panel.querySelector('#af-status');
  const stopBtn = panel.querySelector('#af-stop');
  stopBtn.onclick = ()=>{ autoFavStopRequested = true; logEl.innerHTML += '<div>⏹️ Arrêt demandé...</div>'; };

  const addLog = (txt)=>{ logEl.innerHTML += `<div>${txt}</div>`; logEl.scrollTop = logEl.scrollHeight; };

  // FIX #1 : PRE-SCROLL COMPLET
  addLog('⬇️ Pre-scroll pour charger tout le dressing (Fix v1.5.2)...');
  let lastH=0, stable=0;
  for(let i=0;i<40 && stable<5;i++){
    window.scrollTo(0, document.body.scrollHeight);
    await sleep(800);
    const h=document.body.scrollHeight;
    if(h===lastH) stable++; else stable=0;
    lastH=h;
    if(statusEl) statusEl.textContent=`Chargement... ${document.querySelectorAll('[data-testid="grid-item"]').length} articles chargés`;
    addLog(`📦 Chargés: ${document.querySelectorAll('[data-testid="grid-item"]').length} articles`);
  }
  window.scrollTo(0,0);
  await sleep(600);
  if(statusEl) statusEl.textContent='Dressing en cours...';
  addLog(`✅ Pre-load fini: ${document.querySelectorAll('[data-testid="grid-item"]').length} articles`);

  let favDone = 0;
  let scannedIdx = 0;
  let noNewItemStreak = 0;
  let lastTotalItems = 0;

  const isFavButtonNotFav = (btn)=>{
    if(!btn) return null;
    const pressed = btn.getAttribute('aria-pressed');
    const label = (btn.getAttribute('aria-label')||'').toLowerCase();
    if(pressed === 'false') return true;
    if(pressed === 'true') return false;
    if(label.includes('ajouter') || label.includes('add')) return true;
    if(label.includes('retirer') || label.includes('remove')) return false;
    return null;
  };

  addLog(`Objectif: ${N} favs`);

  while(favDone < N && !autoFavStopRequested){
    const allGridItems = document.querySelectorAll('[data-testid="grid-item"]');
    
    if(allGridItems.length === lastTotalItems){
      noNewItemStreak++;
    } else {
      noNewItemStreak = 0;
      lastTotalItems = allGridItems.length;
    }

    if(scannedIdx >= allGridItems.length){
      if(noNewItemStreak > 8){
        addLog('⚠️ Fin du dressing atteinte - plus d\'articles à charger');
        break;
      }
      window.scrollTo(0, document.body.scrollHeight);
      await sleep(1200 + Math.random()*600);
      continue;
    }

    const item = allGridItems[scannedIdx];
    scannedIdx++;

    try{
      const statusText = item.querySelector('[data-testid*="status-text"]');
      if(statusText){
        const txt = statusText.textContent.trim().toLowerCase();
        if(['vendu','vendido','sold','venduto','verkauft','reservé','reserved'].some(k=>txt.includes(k))){
          continue;
        }
      }

      let favBtn = item.querySelector('button[data-testid="favourite-button"]') 
                || item.querySelector('button[data-testid="favorite-button"]')
                || item.querySelector('button[data-testid*="favourite"]')
                || item.querySelector('button[data-testid*="favorite"]')
                || item.querySelector('button[data-testid="item-favourite-button"]')
                || item.querySelector('button[aria-label*="favoris"]');

      if(!favBtn) continue;

      const needToFav = isFavButtonNotFav(favBtn);
      if(needToFav === false){
        item.style.outline='2px solid #0074de';
        continue;
      }
      if(needToFav === null){
        const hasActiveIcon = item.querySelector('[data-testid="favourite-icon--active"]');
        if(hasActiveIcon) continue;
      }

      favBtn.click();
      favDone++;
      countEl.textContent = favDone;
      barEl.style.width = `${(favDone/N)*100}%`;
      item.style.outline='3px solid #ff2e63';
      addLog(`✅ ${favDone}/${N} fav - article #${scannedIdx}`);

      await sleep(700 + Math.random()*700);
      if(favDone % 12 === 0){
        addLog('💤 Pause humaine 2s...');
        await sleep(1500 + Math.random()*1000);
      }

      if(document.body.textContent.includes('Trop de requêtes')){
        addLog('⚠️ Rate-limit, pause 6s');
        await sleep(6000);
      }

    }catch(e){
      await sleep(500);
    }
  }

  isAutoFavRunning = false;
  // FIX #2 : Message intelligent fin de session
  if(autoFavStopRequested){
    panel.innerHTML = `<h2 style="margin:0 0 10px">⏹️ Stoppé</h2><div style="font-size:20px;margin:10px 0">${favDone} / ${N} favs faits</div><button id="af-close" style="width:100%;padding:12px;background:#ff2e63;color:white;border:none;border-radius:8px;font-weight:bold;cursor:pointer">Fermer</button>`;
  } else if(favDone === 0){
    panel.style.borderColor='#ff9800';
    panel.innerHTML = `<h2 style="margin:0 0 10px">⚠️ 0 / ${N} favs</h2><div style="font-size:13px;margin:10px 0">Aucun article disponible à liker.<br>Déjà likés, vendus ou dressing vide.</div><div style="font-size:11px;color:#aaa;margin-bottom:12px">Fix v1.5.2: ${document.querySelectorAll('[data-testid="grid-item"]').length} articles scannés après pre-load</div><button id="af-close" style="width:100%;padding:12px;background:#ff9800;color:white;border:none;border-radius:8px;font-weight:bold;cursor:pointer">Fermer</button>`;
  } else if(favDone < N){
    panel.style.borderColor='#ff9800';
    panel.innerHTML = `<h2 style="margin:0 0 10px">ℹ️ Terminé: ${favDone} / ${N}</h2><div style="font-size:13px;margin:10px 0">Seulement ${favDone} favs posés sur ${N} demandés.<br><b>Raison:</b> plus d'articles dispo dans ce dressing (le reste est déjà liké/vendu).</div><div style="font-size:11px;color:#aaa;margin-bottom:12px">C'est normal ! Passe à un autre dressing ❤️<br>Fix v1.5.2: ${document.querySelectorAll('[data-testid="grid-item"]').length} articles scannés</div><button id="af-close" style="width:100%;padding:12px;background:#ff9800;color:white;border:none;border-radius:8px;font-weight:bold;cursor:pointer">Fermer</button>`;
  } else {
    panel.innerHTML = `<h2 style="margin:0 0 10px">✅ Terminé !</h2><div style="font-size:20px;margin:10px 0">${favDone} / ${N} favs faits</div><div style="font-size:12px;color:#aaa;margin-bottom:12px">Le dressing a bien été liké ❤️ (v1.5.2)</div><button id="af-close" style="width:100%;padding:12px;background:#ff2e63;color:white;border:none;border-radius:8px;font-weight:bold;cursor:pointer">Fermer</button>`;
  }
  panel.querySelector('#af-close').onclick=()=>{ panel.remove(); vcLauncherClosedUntil=0; setTimeout(()=>injectLauncher(), 800); };
  console.log(`❤️ FIN AUTO-FAV V1.5.2: ${favDone}/${N}`);
}

// Init
setTimeout(injectLauncher, 1500);
setInterval(()=>{ if(!document.getElementById('vinted-cleaner-launcher')) injectLauncher(); }, 3000);

chrome.runtime.onMessage.addListener((msg)=>{
  if(msg.action==='CLEAN_SOLD') runUltraScan(); 
  if(msg.action==='CLEAN_DRESSING') runCleanDressing();
  if(msg.action==='AUTO_FAV') runAutoFavDressing(msg.count);
});
