console.log('💖 Vinted Cleaner v1.5 AUTO-FAV - loaded');

let autoFavStopRequested = false;
let isAutoFavRunning = false;

function injectLauncher(){
  try{
    if(!document.body) return;
    if(document.getElementById('vinted-cleaner-launcher')) return;
    const div=document.createElement('div');
    div.id='vinted-cleaner-launcher';
    div.style.cssText='position:fixed;bottom:20px;right:20px;z-index:999999;background:#111;color:white;padding:12px 16px;border-radius:12px;border:2px solid #ff4444;box-shadow:0 8px 32px rgba(0,0,0,0.6);display:flex;flex-direction:column;gap:8px;font-family:sans-serif;min-width:220px';
    div.innerHTML=`
      <div style="display:flex;justify-content:space-between;align-items:center;width:100%">
        <span style="font-weight:bold;font-size:13px">💖 Cleaner v1.5</span>
        <button id="vc-close" style="background:#222;color:#888;padding:4px 8px;border:none;border-radius:6px;cursor:pointer">✕</button>
      </div>
      <div style="display:flex;gap:6px">
        <button id="vc-sold" style="flex:1;background:#ff4444;color:white;padding:8px 10px;border:none;border-radius:6px;font-weight:bold;cursor:pointer;font-size:12px">🔴 Vendus</button>
        <button id="vc-dress" style="flex:1;background:#0074de;color:white;padding:8px 10px;border:none;border-radius:6px;font-weight:bold;cursor:pointer;font-size:12px">💙 Dressing</button>
      </div>
      <div style="border-top:1px solid #333;padding-top:8px;margin-top:2px">
        <div style="font-size:11px;color:#aaa;margin-bottom:4px;font-weight:bold">❤️ AUTO-FAV Dressing (Clemz-like)</div>
        <div style="display:flex;gap:6px;align-items:center">
          <input id="vc-fav-count" type="number" value="30" min="1" max="200" style="width:60px;background:#222;color:white;border:1px solid #444;border-radius:6px;padding:6px;text-align:center;font-weight:bold">
          <button id="vc-fav" style="flex:1;background:#ff2e63;color:white;padding:8px 10px;border:none;border-radius:6px;font-weight:bold;cursor:pointer;font-size:12px">❤️ Auto-Fav N</button>
        </div>
        <div id="vc-fav-progress" style="display:none;margin-top:6px;font-size:11px;color:#ff8fab;text-align:center"></div>
      </div>
    `;
    document.body.appendChild(div);
    div.querySelector('#vc-sold').onclick=()=>{ console.log('click sold'); runUltraScan(); };
    div.querySelector('#vc-dress').onclick=()=>{ console.log('click dress'); runCleanDressing(); };
    div.querySelector('#vc-fav').onclick=()=>{
      const n = parseInt(div.querySelector('#vc-fav-count').value) || 30;
      console.log('click autofav', n);
      runAutoFavDressing(n);
    };
    div.querySelector('#vc-close').onclick=()=>div.remove();
  }catch(e){ console.error('inject fail', e); }
}

// --- EXISTANT : ULTRA SCAN VENDUS ---
async function runUltraScan(){
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  console.log('🚀 ULTRA SCAN 2420 - Démarrage');
  let bar=document.createElement('div');
  bar.id='vinted-ultra-bar';
  bar.style.cssText='position:fixed;top:0;left:0;width:100%;background:#111;color:white;padding:10px;text-align:center;z-index:9999999;font-family:sans-serif;font-size:14px;border-bottom:3px solid #ff4444';
  bar.innerHTML=`<div>📦 SCAN ULTRA en cours... <span id="ultra-count">0</span> favs chargés | <span id="ultra-sold">0</span> vendus trouvés | RAM optimisée</div><div style="height:4px;background:#333;margin-top:6px"><div id="ultra-progress" style="height:100%;width:0%;background:#ff4444;transition:width 0.3s"></div></div>`;
  try{ document.body.appendChild(bar); }catch(e){}

  let lastCount=0, stable=0, totalSoldFound=0;
  let allSoldData=[];
  const MAX_FAVS=3000;
  const STABLE_LIMIT=10;

  while(stable < STABLE_LIMIT && lastCount < MAX_FAVS){
    const items=document.querySelectorAll('[data-testid="grid-item"]');
    const currentCount=items.length;
    const countEl=document.getElementById('ultra-count');
    const soldEl=document.getElementById('ultra-sold');
    const progEl=document.getElementById('ultra-progress');
    if(countEl) countEl.textContent=currentCount;
    if(progEl) progEl.style.width=`${Math.min(99, (currentCount/2420)*100)}%`;

    if(currentCount>0 && currentCount%200===0){
      console.log(`🧹 Optimisation RAM à ${currentCount} favs`);
      const allImgs=document.querySelectorAll('[data-testid="grid-item"] img');
      for(let i=0;i<allImgs.length-150;i++){
        try{ allImgs[i].removeAttribute('src'); allImgs[i].removeAttribute('srcset'); }catch(e){}
      }
    }

    items.forEach((gridItem, idx)=>{
      if(gridItem.dataset.scanned) return;
      gridItem.dataset.scanned="1";
      try{
        const statusText=gridItem.querySelector('[data-testid*="status-text"]');
        if(statusText && ['vendu','vendido','sold','venduto','verkauft'].includes(statusText.textContent.trim().toLowerCase())){
          const titleEl=gridItem.querySelector('[data-testid*="description-title"]');
          const title=titleEl?titleEl.textContent.trim().substring(0,40):`Article ${idx+1}`;
          const favBtn=gridItem.querySelector('button[data-testid*="favourite"]')||gridItem.querySelector('button[data-testid*="favorite"]')||gridItem.querySelector('button[data-testid*="item-favourite-button"]');
          if(favBtn){
            allSoldData.push({title,favBtn,gridItem,idx});
            totalSoldFound++;
            if(soldEl) soldEl.textContent=totalSoldFound;
            try{ gridItem.style.outline='3px solid #ff4444'; }catch(e){}
          }
        }
      }catch(e){}
    });

    if(items.length>0){
      try{ items[items.length-1].scrollIntoView({block:'end'}); }catch(e){}
      await sleep(200);
      try{ window.scrollBy(0,300); }catch(e){}
    }else{
      try{ window.scrollTo(0,document.body.scrollHeight); }catch(e){}
    }

    await sleep(1100);

    const newCount=document.querySelectorAll('[data-testid="grid-item"]').length;
    if(newCount===lastCount){ stable++; }
    else { stable=0; }
    lastCount=newCount;
    if(newCount>=MAX_FAVS) break;
  }

  const progEl=document.getElementById('ultra-progress');
  if(progEl) progEl.style.width='100%';
  const barEl=document.getElementById('vinted-ultra-bar');
  if(barEl) barEl.innerHTML=`✅ Scan fini: ${lastCount} favs parcourus, ${allSoldData.length} vendus trouvés`;

  console.log(`✅ FIN SCAN: ${lastCount} favs, ${allSoldData.length} vendus`);

  if(allSoldData.length===0){
    alert(`✅ Aucun vendu sur ${lastCount} favs scannés !`);
    if(barEl) setTimeout(()=>barEl.remove(),4000);
    return;
  }

  if(document.getElementById('vinted-control-panel')) document.getElementById('vinted-control-panel').remove();
  const panel=document.createElement('div');
  panel.id='vinted-control-panel';
  panel.style.cssText=`position:fixed;bottom:20px;right:20px;background:#1e1e1e;color:white;padding:16px;border-radius:12px;z-index:9999999;width:380px;max-height:80vh;display:flex;flex-direction:column;border:2px solid #ff4444;font-family:sans-serif;box-shadow:0 8px 32px rgba(0,0,0,0.6)`;
  panel.innerHTML=`
    <h3 style="margin:0 0 8px;font-size:14px">🔴 ${allSoldData.length} vendus trouvés sur ${lastCount} favs</h3>
    <div id="list" style="flex:1;overflow-y:auto;max-height:35vh;border:1px solid #333;border-radius:6px;padding:4px;margin-bottom:10px"></div>
    <div style="display:flex;gap:6px;margin-bottom:8px">
      <button id="selAll" style="flex:1;padding:8px;background:#4CAF50;color:white;border:none;border-radius:6px;font-weight:bold;cursor:pointer">✅ Tout</button>
      <button id="desAll" style="flex:1;padding:8px;background:#555;color:white;border:none;border-radius:6px;cursor:pointer">❌ Aucun</button>
    </div>
    <button id="delBtn" style="width:100%;padding:12px;background:#ff4444;color:white;border:none;border-radius:8px;font-weight:bold;cursor:pointer">🗑️ Supprimer les ${allSoldData.length} vendus</button>
    <button id="close" style="margin-top:6px;width:100%;background:transparent;color:#888;border:none;cursor:pointer">Fermer</button>
  `;
  try{ document.body.appendChild(panel); }catch(e){}
  const listDiv=panel.querySelector('#list');
  allSoldData.forEach((d,i)=>{
    const row=document.createElement('label');
    row.style.cssText='display:flex;align-items:center;gap:6px;padding:5px 0;border-bottom:1px solid #222;font-size:12px;cursor:pointer';
    row.innerHTML=`<input type="checkbox" checked data-i="${i}" style="width:14px;height:14px"><span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${d.title}</span>`;
    listDiv.appendChild(row);
  });
  panel.querySelector('#selAll').onclick=()=>listDiv.querySelectorAll('input').forEach(c=>c.checked=true);
  panel.querySelector('#desAll').onclick=()=>listDiv.querySelectorAll('input').forEach(c=>c.checked=false);
  panel.querySelector('#close').onclick=()=>{ panel.remove(); const b=document.getElementById('vinted-ultra-bar'); if(b) b.remove(); };
  panel.querySelector('#delBtn').onclick=async()=>{
    const checks=[...listDiv.querySelectorAll('input:checked')].map(c=>allSoldData[parseInt(c.dataset.i)]);
    if(!checks.length) return;
    if(!confirm(`Supprimer ${checks.length} vendus ?`)) return;
    let ok=0;
    for(let d of checks){
      try{ d.favBtn.click(); d.gridItem.style.opacity='0.2'; ok++; await sleep(500+Math.random()*300); }catch(e){}
    }
    alert(`✅ ${ok} supprimés !`);
    location.reload();
  };
  try{ window.scrollTo(0,0); }catch(e){}
}

async function runCleanDressing(){
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  let lastHeight=0,noChange=0;
  for(let i=0;i<60 && noChange<5;i++){
    try{ window.scrollTo(0, document.body.scrollHeight); }catch(e){}
    await sleep(1300);
    const h=document.body.scrollHeight; if(h===lastHeight){noChange++;} else {noChange=0;} lastHeight=h;
  }
  const allItems=document.querySelectorAll('[data-testid="grid-item"]'); const favItems=[];
  allItems.forEach(item=>{
    const favBtn=item.querySelector('button[data-testid="favourite-button"]')||item.querySelector('button[data-testid="favorite-button"]')||item.querySelector('button[data-testid="item-favourite-button"]')||item.querySelector('button[aria-label*="favoris"]');
    if(!favBtn) return;
    const ariaLabel=(favBtn.getAttribute('aria-label')||'').toLowerCase(); const pressed=favBtn.getAttribute('aria-pressed');
    const isFav=ariaLabel.includes('retirer')||ariaLabel.includes('remove')||pressed==='true';
    if(isFav){ favItems.push({item,favBtn}); }
  });
  if(favItems.length===0){ alert('✅ Aucun fav de ce dressing'); return; }
  if(document.getElementById('vinted-dressing-panel')) document.getElementById('vinted-dressing-panel').remove();
  const panel=document.createElement('div'); panel.id='vinted-dressing-panel';
  panel.style.cssText='position:fixed;bottom:20px;right:20px;background:#1e1e1e;color:white;padding:16px;border-radius:12px;z-index:9999999;width:360px;border:2px solid #0074de;font-family:sans-serif';
  panel.innerHTML=`<h3 style="margin:0 0 10px">💙 ${favItems.length} favs</h3><div id="vlist" style="max-height:300px;overflow-y:auto;margin-bottom:10px;border:1px solid #333;border-radius:6px;padding:4px"></div><button id="vdel" style="width:100%;padding:12px;background:#0074de;color:white;border:none;border-radius:8px;font-weight:bold;cursor:pointer">Retirer</button><button id="vclose" style="width:100%;margin-top:6px;background:transparent;color:#888;border:none;cursor:pointer">Fermer</button>`;
  try{ document.body.appendChild(panel); }catch(e){ return; }
  const vlist=panel.querySelector('#vlist'); const checks=[];
  favItems.forEach((o,i)=>{
    const title=(o.item.querySelector('[data-testid*="description-title"]')?.textContent||`Article ${i+1}`).slice(0,35);
    const row=document.createElement('label'); row.style.cssText='display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #333;font-size:12px;cursor:pointer';
    row.innerHTML=`<input type="checkbox" checked><span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${title}</span>`;
    vlist.appendChild(row); checks.push({cb:row.querySelector('input'),favBtn:o.favBtn,item:o.item});
  });
  panel.querySelector('#vclose').onclick=()=>panel.remove();
  panel.querySelector('#vdel').onclick=async()=>{
    const sel=checks.filter(c=>c.cb.checked); if(!sel.length) return; if(!confirm(`Retirer ${sel.length}?`)) return;
    for(let i=0;i<sel.length;i++){ try{ sel[i].item.style.opacity='0.3'; sel[i].favBtn.click(); await sleep(600); }catch(e){} }
    alert(`✅ ${sel.length} retirés`); location.reload();
  };
}

// --- NOUVEAU : AUTO-FAV DRESSING (CLEMZ-LIKE) ---
async function runAutoFavDressing(requestedCount){
  if(isAutoFavRunning){
    autoFavStopRequested = true;
    return;
  }
  const sleep = ms => new Promise(r=>setTimeout(r,ms));
  const N = Math.min(Math.max(parseInt(requestedCount)||30, 1), 500); // sécurité max 500
  console.log(`❤️ AUTO-FAV START -> ${N} articles`);

  // Vérif: on est bien sur un dressing ?
  if(!location.href.includes('/member/') && !location.href.includes('/membre/')){
    alert('⚠️ Va sur la page dressing d\'une personne pour utiliser l\'auto-fav ! (ex: vinted.fr/member/12345/items)');
    return;
  }

  autoFavStopRequested = false;
  isAutoFavRunning = true;

  // UI Panel
  if(document.getElementById('vinted-autofav-panel')) document.getElementById('vinted-autofav-panel').remove();
  const panel = document.createElement('div');
  panel.id='vinted-autofav-panel';
  panel.style.cssText='position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#1e1e1e;color:white;padding:20px;border-radius:16px;z-index:99999999;width:400px;border:2px solid #ff2e63;font-family:sans-serif;box-shadow:0 20px 60px rgba(0,0,0,0.8);text-align:center';
  panel.innerHTML=`
    <h2 style="margin:0 0 10px;font-size:16px">❤️ Auto-Fav en cours...</h2>
    <div style="font-size:32px;font-weight:bold;margin:10px 0"><span id="af-count">0</span> / ${N}</div>
    <div style="height:8px;background:#333;border-radius:10px;overflow:hidden;margin-bottom:10px"><div id="af-bar" style="height:100%;width:0%;background:#ff2e63;transition:width 0.3s"></div></div>
    <div id="af-log" style="font-size:11px;color:#aaa;height:60px;overflow-y:auto;background:#111;border-radius:6px;padding:6px;text-align:left;margin-bottom:12px">Démarrage...</div>
    <button id="af-stop" style="width:100%;padding:12px;background:#333;color:white;border:1px solid #555;border-radius:8px;font-weight:bold;cursor:pointer">⏹️ Stop</button>
  `;
  document.body.appendChild(panel);
  const countEl = panel.querySelector('#af-count');
  const barEl = panel.querySelector('#af-bar');
  const logEl = panel.querySelector('#af-log');
  const stopBtn = panel.querySelector('#af-stop');
  stopBtn.onclick = ()=>{ autoFavStopRequested = true; logEl.innerHTML += '<div>⏹️ Arrêt demandé...</div>'; };

  const addLog = (txt)=>{ logEl.innerHTML += `<div>${txt}</div>`; logEl.scrollTop = logEl.scrollHeight; };

  let favDone = 0;
  let scannedIdx = 0;
  let noNewItemStreak = 0;
  let lastTotalItems = 0;

  const isFavButtonNotFav = (btn)=>{
    if(!btn) return null;
    const pressed = btn.getAttribute('aria-pressed');
    const label = (btn.getAttribute('aria-label')||'').toLowerCase();
    // Vinted FR: "Ajouter aux favoris" = pas fav, "Retirer des favoris" = déjà fav
    // Vinted EN: "Add to favourites" vs "Remove from favourites"
    if(pressed === 'false') return true;
    if(pressed === 'true') return false;
    if(label.includes('ajouter') || label.includes('add')) return true;
    if(label.includes('retirer') || label.includes('remove')) return false;
    // fallback: check icône active
    return null;
  };

  addLog(`Objectif: ${N} favs`);

  while(favDone < N && !autoFavStopRequested){
    const allGridItems = document.querySelectorAll('[data-testid="grid-item"]');
    
    if(allGridItems.length === lastTotalItems){
      noNewItemStreak++;
    } else {
      noNewItemStreak = 0;
      lastTotalItems = allGridItems.length;
    }

    // Si on a scanné tous les items chargés, on scroll pour charger plus
    if(scannedIdx >= allGridItems.length){
      if(noNewItemStreak > 8){
        addLog('⚠️ Fin du dressing atteinte');
        break;
      }
      window.scrollTo(0, document.body.scrollHeight);
      await sleep(1200 + Math.random()*600);
      continue;
    }

    const item = allGridItems[scannedIdx];
    scannedIdx++;

    try{
      // Skip vendu / réservé si présent
      const statusText = item.querySelector('[data-testid*="status-text"]');
      if(statusText){
        const txt = statusText.textContent.trim().toLowerCase();
        if(['vendu','vendido','sold','venduto','verkauft','reservé','reserved'].some(k=>txt.includes(k))){
          continue;
        }
      }

      // Trouver bouton fav - multi sélecteurs robustes
      let favBtn = item.querySelector('button[data-testid="favourite-button"]') 
                || item.querySelector('button[data-testid="favorite-button"]')
                || item.querySelector('button[data-testid*="favourite"]')
                || item.querySelector('button[data-testid*="favorite"]')
                || item.querySelector('button[data-testid="item-favourite-button"]')
                || item.querySelector('button[aria-label*="favoris"]')
                || item.querySelector('button[aria-label*="favourite"]');

      if(!favBtn){
        // dernier fallback: chercher dans l'item le premier button avec coeur svg
        const btns = item.querySelectorAll('button');
        for(let b of btns){ if(b.innerHTML.includes('favourite') || b.querySelector('svg')){ favBtn = b; break; } }
      }

      if(!favBtn) continue;

      const needToFav = isFavButtonNotFav(favBtn);
      if(needToFav === false){
        // déjà fav, on skip
        item.style.outline='2px solid #0074de';
        continue;
      }
      if(needToFav === null){
        // état incertain, on tente de deviner via data
        const hasActiveIcon = item.querySelector('[data-testid="favourite-icon--active"], [class*="favourite--active"]');
        if(hasActiveIcon) continue;
      }

      // === ACTION: FAV ===
      favBtn.click();
      favDone++;
      countEl.textContent = favDone;
      barEl.style.width = `${(favDone/N)*100}%`;
      item.style.outline='3px solid #ff2e63';
      item.style.transition='outline 0.3s';
      addLog(`✅ ${favDone}/${N} fav - article #${scannedIdx}`);

      // Délai humain anti rate-limit: 700-1400ms + pause toutes les 12 favs
      await sleep(700 + Math.random()*700);
      if(favDone % 12 === 0){
        addLog('💤 Petite pause humaine 2s...');
        await sleep(1500 + Math.random()*1000);
      }

      // Détection rate-limit Vinted (popup ou texte)
      if(document.body.textContent.includes('Trop de requêtes') || document.body.textContent.includes('Too many requests')){
        addLog('⚠️ Rate-limit Vinted, pause 6s');
        await sleep(6000);
      }

    }catch(e){
      console.error('fav err', e);
      await sleep(500);
    }
  }

  isAutoFavRunning = false;
  if(autoFavStopRequested){
    panel.innerHTML = `<h2 style="margin:0 0 10px">⏹️ Stoppé</h2><div style="font-size:20px;margin:10px 0">${favDone} / ${N} favs faits</div><button id="af-close" style="width:100%;padding:12px;background:#ff2e63;color:white;border:none;border-radius:8px;font-weight:bold;cursor:pointer">Fermer</button>`;
  } else if(favDone >= N){
    panel.innerHTML = `<h2 style="margin:0 0 10px">✅ Terminé !</h2><div style="font-size:20px;margin:10px 0">${favDone} / ${N} favs faits</div><div style="font-size:12px;color:#aaa;margin-bottom:12px">Le dressing a bien été liké ❤️</div><button id="af-close" style="width:100%;padding:12px;background:#ff2e63;color:white;border:none;border-radius:8px;font-weight:bold;cursor:pointer">Fermer</button>`;
  } else {
    panel.innerHTML = `<h2 style="margin:0 0 10px">⚠️ Terminé partiel</h2><div style="font-size:20px;margin:10px 0">${favDone} / ${N} favs faits</div><div style="font-size:12px;color:#aaa;margin-bottom:12px">Plus d'articles disponibles dans ce dressing</div><button id="af-close" style="width:100%;padding:12px;background:#333;color:white;border:1px solid #555;border-radius:8px;font-weight:bold;cursor:pointer">Fermer</button>`;
  }
  panel.querySelector('#af-close').onclick=()=>panel.remove();
  console.log(`❤️ FIN AUTO-FAV: ${favDone}/${N}`);
}

// Init after load
setTimeout(injectLauncher, 1500);
setInterval(()=>{ if(!document.getElementById('vinted-cleaner-launcher')) injectLauncher(); }, 3000);

chrome.runtime.onMessage.addListener((msg)=>{
  if(msg.action==='CLEAN_SOLD') runUltraScan(); 
  if(msg.action==='CLEAN_DRESSING') runCleanDressing();
  if(msg.action==='AUTO_FAV') runAutoFavDressing(msg.count);
});
