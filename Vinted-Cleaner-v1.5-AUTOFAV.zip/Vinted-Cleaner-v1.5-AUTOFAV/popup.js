
document.getElementById('cleanSold')?.addEventListener('click', async()=>{
  let [tab]=await chrome.tabs.query({active:true, currentWindow:true});
  chrome.tabs.sendMessage(tab.id, {action:'CLEAN_SOLD'});
});
document.getElementById('cleanDressing')?.addEventListener('click', async()=>{
  let [tab]=await chrome.tabs.query({active:true, currentWindow:true});
  chrome.tabs.sendMessage(tab.id, {action:'CLEAN_DRESSING'});
});
document.getElementById('autoFav')?.addEventListener('click', async()=>{
  let [tab]=await chrome.tabs.query({active:true, currentWindow:true});
  const count = parseInt(document.getElementById('favCount').value) || 30;
  chrome.tabs.sendMessage(tab.id, {action:'AUTO_FAV', count: count});
});
