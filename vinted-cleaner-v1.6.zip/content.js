// Vinted Cleaner v1.6 Remastered - Base clean vendu favoris par Meta AI - Remaster impeccable tous bugs corrigés - 2026 selector --favourite

(function () {
  'use strict';

  // ============================================================
  // ÉTAT GLOBAL
  // ============================================================
  const VC_STATE = {
    running: false,
    stopRequested: false,
    pillTimer: null
  };

  // ============================================================
  // SÉLECTEURS 2026 (avec fallbacks pour compatibilité anciennes pages)
  // ============================================================
  const CARD_SELECTORS = [
    'div[class*="ItemBox"]',
    '[data-testid="grid-item"]'
  ];

  const FAV_BTN_SELECTORS = [
    'button[data-testid$="--favourite"]',   // ex: product-item-id-9613397964--favourite (2026)
    'button[data-testid="favourite-button"]',
    'button[data-testid="favorite-button"]',
    'button[data-testid="item-favourite-button"]',
    'button[data-testid*="favourite"]',
    'button[aria-label*="favoris"]',
    'button[aria-label*="favourite"]',
    'button[aria-label*="favorite"]'
  ];

  const SOLD_KEYWORDS = [
    'vendu', 'vendido', 'sold', 'venduto', 'verkauft', 'verkocht', 'sprzedane',
    'reservé', 'réservé', 'reserved'
  ];

  // ============================================================
  // UTILITAIRES
  // ============================================================
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  // Délai "humain" entre chaque clic : 750ms + random 800ms
  const humanDelay = () => sleep(750 + Math.random() * 800);

  // Pause si Vinted rate-limit ("Trop de requêtes" dans le body)
  async function checkRateLimit() {
    if (document.body && document.body.textContent.includes('Trop de requêtes')) {
      console.log('[VC 1.6] Rate-limit détecté, pause 6s...');
      showPill('⏳ Pause anti rate-limit...');
      await sleep(6000);
    }
  }

  // FIX COMPTAGE : on part des boutons favoris (1 seul bouton par article,
  // donc jamais de doublon), et non des divs de carte qui peuvent matcher
  // plusieurs wrappers imbriqués par article (ItemBox, ItemBoxNew, etc.)
  // avec un sélecteur class*="ItemBox" -> comptage x3/x4 comme "4060 au lieu
  // de 1119".
  function getAllFavButtons() {
    const combinedSelector = FAV_BTN_SELECTORS.join(',');
    return Array.from(new Set(document.querySelectorAll(combinedSelector)));
  }

  // Retrouve la carte (conteneur de l'article) à partir d'un bouton favori,
  // uniquement pour le style visuel et la détection "vendu" / lien /items/.
  function getCardForButton(btn) {
    for (const sel of CARD_SELECTORS) {
      const card = btn.closest(sel);
      if (card) return card;
    }
    return btn.closest('article') || btn.parentElement || btn;
  }

  // Conservé pour compatibilité mais non utilisé pour le comptage principal.
  // FIX COMPTAGE x3/x4 : on ne part JAMAIS des div[class*="ItemBox"] pour
  // compter les articles. Vinted imbrique plusieurs divs dont le nom de
  // classe contient "ItemBox" (conteneur, wrapper image, wrapper badge...)
  // à l'intérieur d'UNE SEULE carte article. Compter ces divs fait exploser
  // le total (ex: 1119 articles comptés comme 4060, ou pire sur la page
  // favoris). On part donc des BOUTONS favoris (un seul par article, fiable)
  // puis on déduplique par ID d'article réel extrait du lien /items/xxxx.

  function getAllFavButtons() {
    const set = new Set();
    FAV_BTN_SELECTORS.forEach((sel) => {
      document.querySelectorAll(sel).forEach((btn) => set.add(btn));
    });
    return Array.from(set);
  }

  function getCardForButton(btn) {
    for (const sel of CARD_SELECTORS) {
      const card = btn.closest(sel);
      if (card) return card;
    }
    return btn.parentElement || btn;
  }

  // Récupère un identifiant stable pour un item (évite les doublons de scan)
  // Filtre les liens vers /favourite_list et ne garde que /items/{id}
  function getItemId(card) {
    const links = card.querySelectorAll('a[href*="/items/"]');
    for (const link of links) {
      const href = link.getAttribute('href') || '';
      if (href.includes('/favourite_list')) continue;
      const match = href.match(/\/items\/(\d+)/);
      if (match) return match[1];
    }
    return null;
  }

  // Liste dédupliquée des articles réels { card, btn }, un seul par ID.
  // Si aucun ID trouvable (rare, page cassée), on déduplique par bouton lui-même.
  function getAllItems() {
    const buttons = getAllFavButtons();
    const seenIds = new Set();
    const items = [];

    for (const btn of buttons) {
      const card = getCardForButton(btn);
      const id = getItemId(card) || `no-id-${items.length}-${btn.outerHTML.length}`;
      if (seenIds.has(id)) continue;
      seenIds.add(id);
      items.push({ card, btn });
    }

    return items;
  }

  function isSoldCard(card) {
    const statusEl = card.querySelector('[data-testid*="status-text"]');
    if (statusEl) {
      const txt = statusEl.textContent.trim().toLowerCase();
      if (SOLD_KEYWORDS.some((k) => txt.includes(k))) return true;
    }
    // Fallback visuel : contour rouge appliqué par Vinted sur certains thèmes
    const style = window.getComputedStyle(card);
    if (style.outlineColor === 'rgb(255, 46, 99)') return true;
    return false;
  }

  // FIX INVERSION : détection fiable de l'état "déjà favori" d'un bouton.
  // Retourne true UNIQUEMENT si on est sûr que le bouton est déjà actif.
  function isAlreadyFav(btn) {
    if (!btn) return false;

    const pressed = btn.getAttribute('aria-pressed');
    if (pressed === 'true') return true;
    if (pressed === 'false') return false;

    // Inspection de l'icône SVG (coeur plein vs vide)
    const icon = btn.querySelector('[data-testid="favourite-icon"]') || btn.querySelector('svg');
    if (icon) {
      const path = icon.querySelector('path');
      if (path) {
        const fill = (path.getAttribute('fill') || '').toLowerCase();
        const classes = (path.getAttribute('class') || '') + (icon.getAttribute('class') || '');
        if (fill === '#ff2e63') return true;
        if (fill === 'currentcolor' && classes.toLowerCase().includes('filled')) return true;
      }
    }

    // Fallback texte aria-label (FR/EN/ES/IT/DE)
    const label = (btn.getAttribute('aria-label') || '').toLowerCase();
    if (label.includes('retirer') || label.includes('remove') || label.includes('quitar') ||
        label.includes('rimuovi') || label.includes('entfernen')) {
      return true;
    }
    if (label.includes('ajouter') || label.includes('add') || label.includes('añadir') ||
        label.includes('aggiungi') || label.includes('hinzufügen')) {
      return false;
    }

    return false;
  }

  // ============================================================
  // PASTILLE UI (remplace la vieille barre noire centrée)
  // ============================================================
  function showPill(text) {
    let pill = document.getElementById('vc-pill');
    if (!pill) {
      pill = document.createElement('div');
      pill.id = 'vc-pill';
      pill.style.cssText = [
        'position: fixed',
        'top: 16px',
        'right: 16px',
        'background: #111111',
        'color: #ffffff',
        'padding: 10px 18px',
        'border-radius: 24px',
        "font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
        'font-size: 13px',
        'font-weight: 600',
        'z-index: 2147483647',
        'box-shadow: 0 4px 16px rgba(0,0,0,0.25)',
        'transition: opacity 0.4s ease',
        'pointer-events: none',
        'white-space: nowrap'
      ].join(';');
      document.body.appendChild(pill);
    }
    clearTimeout(VC_STATE.pillTimer);
    pill.style.opacity = '1';
    pill.textContent = text;
    return pill;
  }

  function hidePillLater(delay) {
    const pill = document.getElementById('vc-pill');
    if (!pill) return;
    clearTimeout(VC_STATE.pillTimer);
    VC_STATE.pillTimer = setTimeout(() => {
      pill.style.opacity = '0';
      setTimeout(() => pill.remove(), 400);
    }, delay || 3000);
  }

  // ============================================================
  // PRE-SCROLL ROBUSTE (charge tout le contenu lazy-load)
  // Scroll jusqu'en bas + oscillation up/down 800px pour déclencher
  // l'IntersectionObserver de Vinted, jusqu'à stabilité (5x pas de changement)
  // ============================================================
  async function preScrollRobust(onProgress) {
    let lastHeight = 0;
    let stableCount = 0;
    const maxAttempts = 150;

    for (let i = 0; i < maxAttempts && stableCount < 5; i++) {
      if (VC_STATE.stopRequested) break;

      window.scrollTo(0, document.body.scrollHeight);
      await sleep(1000);

      // Oscillation pour forcer le déclenchement du lazy-load
      window.scrollTo(0, Math.max(0, document.body.scrollHeight - 800));
      await sleep(250);
      window.scrollTo(0, document.body.scrollHeight);
      await sleep(400);

      const newHeight = document.body.scrollHeight;
      if (newHeight === lastHeight) {
        stableCount++;
      } else {
        stableCount = 0;
      }
      lastHeight = newHeight;

      if (onProgress) onProgress(getAllItems().length);
    }

    window.scrollTo(0, 0);
    await sleep(500);
  }

  // ============================================================
  // ACTION 1 : AUTO-FAV
  // Clique uniquement sur les boutons NON favoris (isAlreadyFav === false)
  // ============================================================
  async function runAutoFav(target) {
    VC_STATE.running = true;
    VC_STATE.stopRequested = false;

    const N = Math.max(1, parseInt(target, 10) || 30);
    console.log(`[VC 1.6] AutoFav démarré - objectif ${N}`);

    showPill(`⏳ Chargement du dressing...`);
    await preScrollRobust((count) => showPill(`⏳ Chargement... ${count} articles trouvés`));

    const buttons = getAllFavButtons();
    console.log(`[VC 1.6] loaded - ${buttons.length} btns après pre-scroll`);

    let favDone = 0;

    for (const btn of buttons) {
      if (favDone >= N || VC_STATE.stopRequested) break;

      const card = getCardForButton(btn);
      if (isSoldCard(card)) continue;

      // FIX INVERSION : on ne clique QUE si l'item n'est PAS déjà favori
      if (isAlreadyFav(btn)) continue;

      btn.click();
      favDone++;
      showPill(`❤️ ${favDone}/${N}`);
      try {
        card.style.outline = '3px solid #ff2e63';
        card.style.outlineOffset = '2px';
      } catch (e) { /* ignore */ }
      console.log(`[VC 1.6] Fav ${favDone}/${N}`);

      await humanDelay();
      if (favDone % 12 === 0) await sleep(1500 + Math.random() * 1000);
      await checkRateLimit();
    }

    VC_STATE.running = false;
    const stopped = VC_STATE.stopRequested;
    VC_STATE.stopRequested = false;

    if (stopped) {
      showPill(`⏹ Arrêté : ${favDone}/${N}`);
    } else if (favDone >= N) {
      showPill(`✅ Terminé : ${favDone}/${N}`);
    } else {
      showPill(`ℹ️ Fini : ${favDone}/${N} (plus d'articles dispo)`);
    }
    hidePillLater(3000);

    return { favDone, target: N };
  }

  // ============================================================
  // ACTION 2 : NETTOYER VENDUS (page favoris)
  // Ne clique QUE si isAlreadyFav === true ET l'article est vendu
  // ============================================================
  async function runCleanVendus() {
    VC_STATE.running = true;
    VC_STATE.stopRequested = false;

    console.log('[VC 1.6] Nettoyage VENDUS démarré');
    showPill('⏳ Chargement des favoris...');
    await preScrollRobust((count) => showPill(`⏳ Chargement... ${count} articles trouvés`));

    const buttons = getAllFavButtons();
    console.log(`[VC 1.6] loaded - ${buttons.length} btns après pre-scroll`);

    let removed = 0;
    let soldFound = 0;

    for (const btn of buttons) {
      if (VC_STATE.stopRequested) break;

      const card = getCardForButton(btn);
      if (!isSoldCard(card)) continue;
      soldFound++;

      // FIX INVERSION : on ne clique QUE si l'article est bien déjà en favori
      if (!isAlreadyFav(btn)) continue;

      btn.click();
      removed++;
      showPill(`🗑 ${removed} vendu(s) retiré(s)`);
      console.log(`[VC 1.6] Vendu retiré ${removed}`);

      await humanDelay();
      if (removed % 12 === 0) await sleep(1500 + Math.random() * 1000);
      await checkRateLimit();
    }

    VC_STATE.running = false;
    VC_STATE.stopRequested = false;
    showPill(`✅ Terminé : ${removed}/${soldFound} vendu(s) retiré(s)`);
    hidePillLater(3000);

    return { removed, soldFound };
  }

  // ============================================================
  // ACTION 3 : NETTOYER DRESSING (page profil / dressing d'un membre)
  // Retire tous les favoris déjà posés sur ce dressing précis
  // Ne clique QUE si isAlreadyFav === true
  // ============================================================
  async function runCleanDressing() {
    VC_STATE.running = true;
    VC_STATE.stopRequested = false;

    console.log('[VC 1.6] Nettoyage DRESSING démarré');
    showPill('⏳ Chargement du dressing...');
    await preScrollRobust((count) => showPill(`⏳ Chargement... ${count} articles trouvés`));

    const buttons = getAllFavButtons();
    console.log(`[VC 1.6] loaded - ${buttons.length} btns après pre-scroll`);

    let removed = 0;

    for (const btn of buttons) {
      if (VC_STATE.stopRequested) break;

      // FIX INVERSION : on ne clique QUE si l'article est déjà favori
      if (!isAlreadyFav(btn)) continue;

      const card = getCardForButton(btn);
      btn.click();
      removed++;
      showPill(`💔 ${removed} retiré(s)`);
      try { card.style.opacity = '0.35'; } catch (e) { /* ignore */ }
      console.log(`[VC 1.6] Retiré du dressing ${removed}`);

      await humanDelay();
      if (removed % 12 === 0) await sleep(1500 + Math.random() * 1000);
      await checkRateLimit();
    }

    VC_STATE.running = false;
    VC_STATE.stopRequested = false;
    showPill(`✅ Terminé : ${removed} article(s) retiré(s) de ce dressing`);
    hidePillLater(3000);

    return { removed };
  }

  // ============================================================
  // MESSAGERIE avec le popup
  // ============================================================
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.action) return false;

    if (msg.action === 'PING') {
      sendResponse({ ok: true, running: VC_STATE.running });
      return true;
    }

    if (msg.action === 'STOP') {
      VC_STATE.stopRequested = true;
      sendResponse({ ok: true });
      return true;
    }

    if (VC_STATE.running) {
      sendResponse({ ok: false, error: 'Une action est déjà en cours.' });
      return true;
    }

    if (msg.action === 'AUTOFAV') {
      runAutoFav(msg.target).catch((err) => console.error('[VC 1.6] Erreur AutoFav:', err));
      sendResponse({ ok: true });
      return true;
    }

    if (msg.action === 'CLEAN_VENDUS') {
      runCleanVendus().catch((err) => console.error('[VC 1.6] Erreur Nettoyage Vendus:', err));
      sendResponse({ ok: true });
      return true;
    }

    if (msg.action === 'CLEAN_DRESSING') {
      runCleanDressing().catch((err) => console.error('[VC 1.6] Erreur Nettoyage Dressing:', err));
      sendResponse({ ok: true });
      return true;
    }

    return false;
  });

  // ============================================================
  // LOG DE CHARGEMENT
  // ============================================================
  const initialBtnCount = getAllFavButtons().length;
  console.log(`[VC 1.6] loaded - ${initialBtnCount} btns`);
})();
