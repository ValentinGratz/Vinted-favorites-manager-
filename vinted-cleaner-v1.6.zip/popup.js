// Vinted Cleaner v1.6 Remastered - popup logic

const statusEl = document.getElementById('status');
const favCountInput = document.getElementById('favCount');
const btnStart = document.getElementById('btnStart');
const btnStop = document.getElementById('btnStop');
const btnCleanVendus = document.getElementById('btnCleanVendus');
const btnCleanDressing = document.getElementById('btnCleanDressing');

function setStatus(text) {
  statusEl.textContent = text;
}

function getActiveTab() {
  return new Promise((resolve, reject) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (chrome.runtime.lastError || !tabs || !tabs[0]) {
        reject(new Error('Impossible de trouver l\'onglet actif.'));
        return;
      }
      resolve(tabs[0]);
    });
  });
}

function sendToContent(message) {
  return new Promise(async (resolve, reject) => {
    try {
      const tab = await getActiveTab();
      if (!tab.url || !/vinted\.(fr|com|de|es|it)/.test(tab.url)) {
        reject(new Error('Ouvre une page Vinted (favoris ou dressing) avant de lancer une action.'));
        return;
      }
      chrome.tabs.sendMessage(tab.id, message, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error('Recharge la page Vinted puis réessaie (script pas encore injecté).'));
          return;
        }
        resolve(response);
      });
    } catch (err) {
      reject(err);
    }
  });
}

btnStart.addEventListener('click', async () => {
  const target = parseInt(favCountInput.value, 10) || 50;
  setStatus(`Lancement AutoFav (${target})...`);
  try {
    const res = await sendToContent({ action: 'AUTOFAV', target });
    if (res && res.ok) {
      setStatus(`✅ AutoFav lancé sur la page. Regarde la pastille en haut à droite.`);
    } else {
      setStatus(`⚠ ${res && res.error ? res.error : 'Action refusée.'}`);
    }
  } catch (err) {
    setStatus(`⚠ ${err.message}`);
  }
});

btnStop.addEventListener('click', async () => {
  setStatus('Arrêt demandé...');
  try {
    await sendToContent({ action: 'STOP' });
    setStatus('⏹ Arrêt demandé, la page va s\'arrêter au prochain clic.');
  } catch (err) {
    setStatus(`⚠ ${err.message}`);
  }
});

btnCleanVendus.addEventListener('click', async () => {
  setStatus('Nettoyage des articles vendus...');
  try {
    const res = await sendToContent({ action: 'CLEAN_VENDUS' });
    if (res && res.ok) {
      setStatus('✅ Nettoyage VENDUS lancé sur la page.');
    } else {
      setStatus(`⚠ ${res && res.error ? res.error : 'Action refusée.'}`);
    }
  } catch (err) {
    setStatus(`⚠ ${err.message}`);
  }
});

btnCleanDressing.addEventListener('click', async () => {
  setStatus('Nettoyage du dressing...');
  try {
    const res = await sendToContent({ action: 'CLEAN_DRESSING' });
    if (res && res.ok) {
      setStatus('✅ Nettoyage DRESSING lancé sur la page.');
    } else {
      setStatus(`⚠ ${res && res.error ? res.error : 'Action refusée.'}`);
    }
  } catch (err) {
    setStatus(`⚠ ${err.message}`);
  }
});
