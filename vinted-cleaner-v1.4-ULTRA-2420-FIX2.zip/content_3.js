
console.log('💖 Vinted Cleaner v1.3 BATCH 300 - loaded');

function injectLauncher(){
  try{
    if(!document.body) return;
    if(document.getElementById('vinted-cleaner-launcher')) return;
    const div = document.createElement('div');
    div.id='vinted-cleaner-launcher';
    div.style.cssText='position:fixed;bottom:20px;right:20px;z-index:999999;background:#111;color:white;padding:12px 16px;border-radius:12px;border:2px solid #ff4444;box-shadow:0 8px 32px rgba(0,0,0,0.6);display:flex;gap:8px;align-items:center;font-family:sans-serif';
    div.innerHTML = `
      <span style="font-weight:bold;font-size:13px">💖 Cleaner v1.3</span>
      <button id="vc-sold" style="background:#ff4444;color:white;padding:8px 12px;border:none;border-radius:6px;font-weight:bold;cursor:pointer;font-size:12px">🔴 Vendus (batch 300)</button>
      <button id="vc-dress" style="background:#0074de;color:white;padding:8px 12px;border:none;border-radius:6px;font-weight:bold;cursor:pointer;font-size:12px">💙 Dressing</button>
      <button id="vc-close" style="background:#222;color:#888;padding:6px 8px;border:none;border-radius:6px;cursor:pointer">✕</button>
    `;
    document.body.appendChild(div);
    div.querySelector('#vc-sold').onclick = () => runCleanSoldBatch();
    div.querySelector('#vc-dress').onclick = () => runCleanDressing();
    div.querySelector('#vc-close').onclick = () => div.remove();
  }catch(e){ console.log('inject fail', e); }
}
setTimeout(injectLauncher, 2500);
// No more setInterval that causes spam when body is null

chrome.runtime.onMessage.addListener((msg)=>{
  if(msg.action==='CLEAN_SOLD') runCleanSoldBatch();
  if(msg.action==='CLEAN_DRESSING') runCleanDressing();
});

async function runCleanSoldBatch(){
  console.log('🚀 BATCH MODE 300 - Démarrage');
  const sleep = ms => new Promise(r=>setTimeout(r,ms));
  
  // Stop if already too many items to avoid crash
  let currentItems = document.querySelectorAll('[data-testid="grid-item"]').length;
  console.log(`Actuellement ${currentItems} favs chargés`);
  
  // If already > 400, don't scroll more, process directly
  let lastCount = currentItems;
  let stable = 0;
  const BATCH_LIMIT = 350; // On s'arrête à 350 pour ne pas crasher Vinted
  
  if(currentItems < BATCH_LIMIT){
    // Progress
    let bar = document.createElement('div');
    bar.id='vinted-batch-bar';
    bar.style.cssText='position:fixed;top:0;left:0;width:100%;background:#111;color:white;padding:8px;text-align:center;z-index:999999;font-family:sans-serif;font-size:13px;border-bottom:2px solid #ff4444';
    bar.textContent=`📦 Batch mode: chargement jusqu'à ${BATCH_LIMIT} max pour éviter écran blanc...`;
    if(document.body) document.body.appendChild(bar);
    
    while(stable < 5 && lastCount < BATCH_LIMIT){
      const items = document.querySelectorAll('[data-testid="grid-item"]');
      if(items.length>0){
        try{ items[items.length-1].scrollIntoView({block:'end'}); }catch(e){}
        await sleep(300);
        try{ window.scrollBy(0,400); }catch(e){}
      }
      await sleep(1200);
      const newCount = document.querySelectorAll('[data-testid="grid-item"]').length;
      if(document.getElementById('vinted-batch-bar')) document.getElementById('vinted-batch-bar').textContent = `📦 ${newCount}/${BATCH_LIMIT} favs chargés...`;
      if(newCount===lastCount) stable++; else stable=0;
      lastCount=newCount;
      if(newCount>=BATCH_LIMIT) break;
    }
    const b=document.getElementById('vinted-batch-bar'); if(b) b.remove();
  }
  
  const allItems = document.querySelectorAll('[data-testid="grid-item"]');
  console.log(`Analyse de ${allItems.length} favs`);
  
  const soldData=[];
  allItems.forEach((gridItem, idx)=>{
    try{
      const statusText = gridItem.querySelector('[data-testid*="status-text"]');
      if(statusText && ['vendu','vendido','sold','venduto','verkauft','verkocht','sprzedane'].includes(statusText.textContent.trim().toLowerCase())){
        const titleEl = gridItem.querySelector('[data-testid*="description-title"]');
        const title = titleEl ? titleEl.textContent.trim().substring(0,40) : `Article ${idx+1}`;
        const favBtn = gridItem.querySelector('button[data-testid*="favourite"]') || gridItem.querySelector('button[data-testid*="favorite"]') || gridItem.querySelector('button[data-testid*="item-favourite-button"]');
        if(favBtn) soldData.push({title, favBtn, gridItem});
      }
    }catch(e){}
  });
  
  console.log(`Vendus: ${soldData.length} / ${allItems.length}`);
  
  if(soldData.length===0){
    alert(`✅ Aucun vendu trouvé sur ce batch de ${allItems.length} favs.\n\nRecharge la page et relance pour le batch suivant.\n\nSi tu as 2420 favs au total, il faut relancer 7-8 fois.`);
    return;
  }
  
  // Highlight only first 50 to avoid crash
  soldData.slice(0,50).forEach(d=>{ try{ d.gridItem.style.outline='3px solid #ff4444'; }catch(e){} });
  
  if(document.getElementById('vinted-control-panel')) document.getElementById('vinted-control-panel').remove();
  const panel=document.createElement('div');
  panel.id='vinted-control-panel';
  panel.style.cssText=`position:fixed;bottom:20px;right:20px;background:#1e1e1e;color:white;padding:16px;border-radius:12px;z-index:999999;width:380px;max-height:80vh;display:flex;flex-direction:column;border:2px solid #ff4444;font-family:sans-serif`;
  panel.innerHTML=`
    <h3 style="margin:0 0 8px;font-size:14px">🔴 ${soldData.length} vendus / ${allItems.length} (batch)</h3>
    <div style="font-size:11px;color:#aaa;margin-bottom:8px">Mode anti-crash: on traite par 300. Il te reste ~${2420-allItems.length} favs à charger après ce batch.</div>
    <div id="list" style="flex:1;overflow-y:auto;max-height:35vh;border:1px solid #333;border-radius:6px;padding:4px;margin-bottom:10px"></div>
    <div style="display:flex;gap:6px;margin-bottom:8px">
      <button id="selAll" style="flex:1;padding:8px;background:#4CAF50;color:white;border:none;border-radius:6px;font-weight:bold;cursor:pointer">✅ Tout</button>
      <button id="desAll" style="flex:1;padding:8px;background:#555;color:white;border:none;border-radius:6px;cursor:pointer">❌ Aucun</button>
    </div>
    <button id="delBtn" style="width:100%;padding:12px;background:#ff4444;color:white;border:none;border-radius:8px;font-weight:bold;cursor:pointer">🗑️ Supprimer ${soldData.length} + recharger auto</button>
    <button id="close" style="margin-top:6px;width:100%;background:transparent;color:#888;border:none;cursor:pointer">Fermer</button>
  `;
  try{ document.body.appendChild(panel); }catch(e){ return; }
  const listDiv=panel.querySelector('#list');
  soldData.forEach((d,i)=>{
    const row=document.createElement('label');
    row.style.cssText='display:flex;align-items:center;gap:6px;padding:5px 0;border-bottom:1px solid #222;font-size:12px;cursor:pointer';
    row.innerHTML=`<input type="checkbox" checked data-i="${i}" style="width:14px;height:14px"><span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${d.title}</span>`;
    listDiv.appendChild(row);
  });
  panel.querySelector('#selAll').onclick=()=>listDiv.querySelectorAll('input').forEach(c=>c.checked=true);
  panel.querySelector('#desAll').onclick=()=>listDiv.querySelectorAll('input').forEach(c=>c.checked=false);
  panel.querySelector('#close').onclick=()=>panel.remove();
  panel.querySelector('#delBtn').onclick=async()=>{
    const checks=[...listDiv.querySelectorAll('input:checked')].map(c=>soldData[parseInt(c.dataset.i)]);
    if(!checks.length) return;
    if(!confirm(`Supprimer ${checks.length} vendus de ce batch ?`)) return;
    let ok=0;
    for(let d of checks){
      try{ d.favBtn.click(); d.gridItem.style.opacity='0.2'; ok++; await sleep(600+Math.random()*300); }catch(e){}
    }
    alert(`✅ ${ok} supprimés sur ce batch.\nLa page va se recharger pour le batch suivant.\nRefais 🔴 Vendus pour continuer tes 2420.`);
    location.reload();
  };
}

async function runCleanDressing(){
  console.log('👕 Dressing Cleaner...');
  const sleep = ms => new Promise(r=>setTimeout(r,ms));
  let lastHeight=0,noChange=0;
  for(let i=0;i<60 && noChange<5;i++){
    try{ window.scrollTo(0, document.body.scrollHeight); }catch(e){}
    await sleep(1300);
    const h=document.body.scrollHeight; if(h===lastHeight){noChange++;} else {noChange=0;} lastHeight=h;
  }
  const allItems=document.querySelectorAll('[data-testid="grid-item"]'); const favItems=[];
  allItems.forEach(item=>{
    const favBtn = item.querySelector('button[data-testid="favourite-button"]') || item.querySelector('button[data-testid="favorite-button"]') || item.querySelector('button[data-testid="item-favourite-button"]') || item.querySelector('button[aria-label*="favoris"]') || item.querySelector('button[aria-label*="favourite"]') || item.querySelector('button[aria-label*="favorite"]');
    if(!favBtn) return;
    const ariaLabel = (favBtn.getAttribute('aria-label')||'').toLowerCase(); const pressed = favBtn.getAttribute('aria-pressed');
    const isFav = ariaLabel.includes('retirer') || ariaLabel.includes('remove') || pressed === 'true';
    if(isFav){ favItems.push({item, favBtn}); }
  });
  if(favItems.length===0){ alert('✅ Aucun fav de ce dressing'); return; }
  favItems.slice(0,50).forEach(({item})=>{ try{ item.style.outline='3px solid #0074de'; }catch(e){} });
  if(document.getElementById('vinted-dressing-panel')) document.getElementById('vinted-dressing-panel').remove();
  const panel=document.createElement('div'); panel.id='vinted-dressing-panel';
  panel.style.cssText='position:fixed;bottom:20px;right:20px;background:#1e1e1e;color:white;padding:16px;border-radius:12px;z-index:999999;width:360px;border:2px solid #0074de;font-family:sans-serif';
  panel.innerHTML=`<h3 style="margin:0 0 10px">💙 ${favItems.length} favs dans ce dressing</h3><div id="vlist" style="max-height:300px;overflow-y:auto;margin-bottom:10px;border:1px solid #333;border-radius:6px;padding:4px"></div><div style="display:flex;gap:6px;margin-bottom:8px"><button id="vselAll" style="flex:1;padding:8px;background:#4CAF50;color:white;border:none;border-radius:6px;cursor:pointer">✅ Tout</button><button id="vdesAll" style="flex:1;padding:8px;background:#555;color:white;border:none;border-radius:6px;cursor:pointer">❌ Aucun</button></div><button id="vdel" style="width:100%;padding:12px;background:#0074de;color:white;border:none;border-radius:8px;font-weight:bold;cursor:pointer">Retirer la sélection</button><button id="vclose" style="width:100%;margin-top:6px;background:transparent;color:#888;border:none;cursor:pointer">Fermer</button>`;
  try{ document.body.appendChild(panel); }catch(e){ return; }
  const vlist=panel.querySelector('#vlist'); const checks=[];
  favItems.forEach((o,i)=>{
    const title=(o.item.querySelector('[data-testid*="description-title"]')?.textContent||`Article ${i+1}`).slice(0,35);
    const row=document.createElement('label'); row.style.cssText='display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #333;font-size:12px;cursor:pointer';
    row.innerHTML=`<input type="checkbox" checked><span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${title}</span>`;
    vlist.appendChild(row); checks.push({cb:row.querySelector('input'), favBtn:o.favBtn, item:o.item});
  });
  panel.querySelector('#vselAll').onclick=()=>checks.forEach(c=>c.cb.checked=true);
  panel.querySelector('#vdesAll').onclick=()=>checks.forEach(c=>c.cb.checked=false);
  panel.querySelector('#vclose').onclick=()=>panel.remove();
  panel.querySelector('#vdel').onclick=async()=>{
    const sel=checks.filter(c=>c.cb.checked); if(!sel.length) return; if(!confirm(`Retirer ${sel.length} favs?`)) return;
    for(let i=0;i<sel.length;i++){ try{ sel[i].item.style.opacity='0.3'; sel[i].favBtn.click(); await sleep(600); }catch(e){} }
    alert(`✅ ${sel.length} retirés`); location.reload();
  };
}
