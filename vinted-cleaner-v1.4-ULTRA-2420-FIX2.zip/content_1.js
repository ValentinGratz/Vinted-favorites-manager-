console.log('💖 Vinted Cleaner Extension loaded - HIC FIX v1.1');

function injectLauncher(){
  if(document.getElementById('vinted-cleaner-launcher')) return;
  const div = document.createElement('div');
  div.id='vinted-cleaner-launcher';
  div.innerHTML = `
    <span style="font-weight:bold;font-size:13px">💖 Cleaner</span>
    <button id="vc-sold" style="background:#ff4444;color:white">🔴 Vendus</button>
    <button id="vc-dress" style="background:#0074de;color:white">💙 Dressing</button>
    <button id="vc-close" style="background:#222;color:#888">✕</button>
  `;
  document.body.appendChild(div);
  div.querySelector('#vc-sold').onclick = () => runCleanSold();
  div.querySelector('#vc-dress').onclick = () => runCleanDressing();
  div.querySelector('#vc-close').onclick = () => div.remove();
}
setTimeout(injectLauncher, 2000);
setInterval(()=>{ if(!document.getElementById('vinted-cleaner-launcher') && !document.getElementById('vinted-control-panel') && !document.getElementById('vinted-dressing-panel')) injectLauncher(); }, 5000);

chrome.runtime.onMessage.addListener((msg)=>{
  if(msg.action==='CLEAN_SOLD') runCleanSold();
  if(msg.action==='CLEAN_DRESSING') runCleanDressing();
});


async function runCleanSold(){
  console.log('🚀 Vinted Favorites Sorter - EXTENSION HIC FIX...');
  function showModal(message, type = 'info') {
    return new Promise(resolve => {
      const modal = document.createElement('div');
      modal.style.cssText = `position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 25px 30px; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.3); z-index: 10001; font-family: sans-serif; max-width: 400px; border-left: 4px solid ${type === 'error' ? '#ff4444' : type === 'success' ? '#4CAF50' : '#6496ff'};`;
      const text = document.createElement('p'); text.textContent = message; text.style.cssText = 'margin: 0 0 20px 0; font-size: 14px; color: #333;';
      const btn = document.createElement('button'); btn.textContent = 'OK'; btn.style.cssText = `background: ${type === 'error' ? '#ff4444' : type === 'success' ? '#4CAF50' : '#6496ff'}; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; width: 100%;`; btn.onclick = () => {modal.remove();resolve();};
      modal.appendChild(text); modal.appendChild(btn); document.body.appendChild(modal);
    });
  }
  function showConfirm(message) {
    return new Promise(resolve => {
      const modal = document.createElement('div'); modal.style.cssText = `position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 25px 30px; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.3); z-index: 10001; font-family: sans-serif; max-width: 450px; border-left: 4px solid #ff4444;`;
      const text = document.createElement('p'); text.textContent = message; text.style.cssText = 'margin: 0 0 20px 0; font-size: 14px; color: #333;'; const bc = document.createElement('div'); bc.style.cssText = 'display: flex; gap: 10px;';
      const confirmBtn = document.createElement('button'); confirmBtn.textContent = '✅ Oui, supprimer'; confirmBtn.style.cssText = `flex: 1; background: #ff4444; color: white; border: none; padding: 10px; border-radius: 6px; cursor: pointer; font-weight: bold;`; confirmBtn.onclick = () => {modal.remove();resolve(true);};
      const cancelBtn = document.createElement('button'); cancelBtn.textContent = '❌ Annuler'; cancelBtn.style.cssText = `flex: 1; background: #ccc; color: #333; border: none; padding: 10px; border-radius: 6px; cursor: pointer; font-weight: bold;`; cancelBtn.onclick = () => {modal.remove();resolve(false);};
      bc.appendChild(confirmBtn); bc.appendChild(cancelBtn); modal.appendChild(text); modal.appendChild(bc); document.body.appendChild(modal); text.textContent = message;
    });
  }

  // Progress bar
  let progressBar = document.createElement('div');
  progressBar.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:6px;background:#222;z-index:999999;';
  progressBar.innerHTML = '<div id="vinted-progress" style="height:100%;width:0%;background:linear-gradient(90deg,#ff4444,#ff8888);transition:width 0.3s"></div><div id="vinted-count" style="position:fixed;top:10px;left:50%;transform:translateX(-50%);background:#1e1e1e;color:white;padding:8px 16px;border-radius:20px;font-family:sans-serif;font-size:13px;z-index:999999;border:1px solid #ff4444">📦 Chargement: 0 favs</div>';
  document.body.appendChild(progressBar);

  let lastCount = 0; let stableCount = 0; const maxStable = 8; let attempts = 0; const maxAttempts = 300;
  while(attempts < maxAttempts && stableCount < maxStable){
    const items = document.querySelectorAll('[data-testid="grid-item"]');
    const currentCount = items.length;
    const countEl = document.getElementById('vinted-count');
    const progEl = document.getElementById('vinted-progress');
    if(countEl) countEl.textContent = `📦 ${currentCount} favs chargés... (${stableCount}/${maxStable})`;
    if(progEl) progEl.style.width = `${Math.min(95, (attempts/maxAttempts)*100)}%`;
    if(items.length > 0){
      const lastItem = items[items.length - 1];
      lastItem.scrollIntoView({behavior: 'smooth', block: 'end'});
      await new Promise(r=>setTimeout(r, 400));
      window.scrollBy(0, 500);
    } else {
      window.scrollTo(0, document.body.scrollHeight);
    }
    await new Promise(r=>setTimeout(r, 1500));
    if(attempts % 3 === 0){
      window.scrollBy(0, -800);
      await new Promise(r=>setTimeout(r, 600));
      window.scrollTo(0, document.body.scrollHeight);
      await new Promise(r=>setTimeout(r, 800));
    }
    const newCount = document.querySelectorAll('[data-testid="grid-item"]').length;
    if(newCount === lastCount){ stableCount++; } else { stableCount = 0; }
    lastCount = newCount; attempts++;
  }
  const progEl = document.getElementById('vinted-progress');
  const countEl = document.getElementById('vinted-count');
  if(progEl) progEl.style.width='100%';
  if(countEl) countEl.textContent=`✅ Fini: ${lastCount} favs`;
  setTimeout(()=>{ const el=document.getElementById('vinted-count'); if(el && el.parentElement) el.parentElement.parentElement?.remove(); const bar=document.querySelector('div[style*="position:fixed;top:0;left:0;width:100%;height:6px"]'); if(bar) bar.remove(); }, 3000);
  // Remove progress div we created earlier if still there
  setTimeout(()=>{ try{progressBar.remove()}catch(e){} }, 3500);

  const allItems = document.querySelectorAll('[data-testid="grid-item"]');
  const soldItems = [];
  allItems.forEach(gridItem => {
    const statusText = gridItem.querySelector('[data-testid*="status-text"]');
    if (statusText && ['vendu','vendido','sold','venduto','verkauft','verkocht','sprzedane'].includes(statusText.textContent.trim().toLowerCase())) {
      soldItems.push(gridItem);
    }
  });
  console.log(`Vendus: ${soldItems.length} / ${allItems.length}`);
  if (soldItems.length === 0) {await showModal(`✅ Aucun vendu trouvé sur ${allItems.length} favs !`, 'success'); return;}

  soldItems.forEach(item => {
    item.style.outline='4px solid #ff4444'; item.style.borderRadius='12px'; item.style.position='relative';
    if(!item.querySelector('.sold-badge')){
      const badge = document.createElement('div'); badge.className='sold-badge'; badge.textContent='🔴 VENDU'; badge.style.cssText=`position:absolute;top:10px;left:10px;background:#ff4444;color:white;padding:6px 12px;border-radius:20px;font-weight:bold;font-size:12px;z-index:100;`; item.appendChild(badge);
    }
  });

  if(document.getElementById('vinted-control-panel')) document.getElementById('vinted-control-panel').remove();
  const controlPanel = document.createElement('div'); controlPanel.id='vinted-control-panel';
  controlPanel.style.cssText=`position:fixed;bottom:20px;right:20px;background:linear-gradient(135deg,#1e1e1e 0%,#2d2d2d 100%);color:white;padding:20px;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,0.4);z-index:10000;font-family:sans-serif;max-width:380px;border:2px solid #ff4444;`;
  controlPanel.innerHTML=`<h3 style="margin:0 0 15px 0;font-size:16px;border-bottom:2px solid #ff4444;padding-bottom:10px">🎯 ${soldItems.length} vendus / ${allItems.length} favs</h3><div id="list" style="max-height:350px;overflow-y:auto;margin-bottom:15px"></div><div style="display:flex;gap:8px;margin-bottom:12px"><button id="selAll" style="flex:1;padding:10px;background:#4CAF50;color:white;border:none;border-radius:6px;cursor:pointer;font-weight:bold">✅ Tout</button><button id="deselAll" style="flex:1;padding:10px;background:#777;color:white;border:none;border-radius:6px;cursor:pointer;font-weight:bold">❌ Aucun</button></div><button id="delBtn" style="width:100%;padding:14px;background:linear-gradient(135deg,#ff4444 0%,#cc0000 100%);color:white;border:none;border-radius:8px;cursor:pointer;font-weight:bold;font-size:14px">🗑️ Supprimer la sélection</button><button id="closeBtn" style="position:absolute;top:8px;right:8px;background:rgba(255,68,68,0.8);color:white;border:none;border-radius:50%;width:28px;height:28px;cursor:pointer;font-weight:bold">✕</button>`;
  document.body.appendChild(controlPanel);
  const listDiv=controlPanel.querySelector('#list'); const checkboxes=[];
  soldItems.forEach((item,i)=>{
    const titleEl=item.querySelector('[data-testid*="description-title"]'); const t=(titleEl?titleEl.textContent.trim().substring(0,35):`Article ${i+1}`);
    const label=document.createElement('label'); label.style.cssText='cursor:pointer;display:flex;align-items:center;padding:8px 0;font-size:13px;border-bottom:1px solid #444';
    label.innerHTML=`<input type="checkbox" checked style="margin-right:8px;width:16px;height:16px"><span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${t}</span>`;
    listDiv.appendChild(label); checkboxes.push({cb:label.querySelector('input'), item});
  });
  controlPanel.querySelector('#selAll').onclick=()=>checkboxes.forEach(c=>c.cb.checked=true);
  controlPanel.querySelector('#deselAll').onclick=()=>checkboxes.forEach(c=>c.cb.checked=false);
  controlPanel.querySelector('#closeBtn').onclick=()=>controlPanel.remove();
  controlPanel.querySelector('#delBtn').onclick=async()=>{
    const selected=checkboxes.filter(c=>c.cb.checked).map(c=>c.item);
    if(selected.length===0) return;
    if(!confirm(`Supprimer ${selected.length} vendus ?`)) return;
    let success=0;
    for(const item of selected){
      const favBtn=item.querySelector('button[data-testid*="favourite"]')||item.querySelector('button[data-testid*="favorite"]');
      if(favBtn){favBtn.click(); await new Promise(r=>setTimeout(r,500)); success++; item.style.opacity='0.3';}
    }
    alert(`✅ ${success} supprimés`); location.reload();
  };
  window.scrollTo(0,0);
}


// ============ 2) CODE DRESSING CLEANER (ton vinted-dressing-fav-cleaner-FIXED.js UNIVERSAL) ============
async function runCleanDressing(){
  console.log('👕 Dressing Cleaner via Extension...');
  const sleep = ms => new Promise(r=>setTimeout(r,ms));
  let lastHeight=0,noChange=0;
  for(let i=0;i<100 && noChange<5;i++){
    window.scrollTo(0, document.body.scrollHeight); await sleep(1300);
    const h=document.body.scrollHeight; if(h===lastHeight){noChange++;} else {noChange=0;} lastHeight=h;
  }
  const allItems=document.querySelectorAll('[data-testid="grid-item"]'); const favItems=[];
  allItems.forEach(item=>{
    const favBtn = item.querySelector('button[data-testid="favourite-button"]') || item.querySelector('button[data-testid="favorite-button"]') || item.querySelector('button[data-testid="item-favourite-button"]') || item.querySelector('button[aria-label*="favoris"]') || item.querySelector('button[aria-label*="favourite"]') || item.querySelector('button[aria-label*="favorite"]') || item.querySelector('button[aria-label*="favoritos"]') || item.querySelector('button[aria-label*="preferiti"]');
    if(!favBtn) return;
    const ariaLabel = (favBtn.getAttribute('aria-label')||'').toLowerCase(); const pressed = favBtn.getAttribute('aria-pressed');
    const isFav = ariaLabel.includes('retirer') || ariaLabel.includes('remove') || ariaLabel.includes('quitar') || ariaLabel.includes('eliminar') || ariaLabel.includes('rimuovi') || ariaLabel.includes('entfernen') || pressed === 'true';
    if(isFav){ favItems.push({item, favBtn}); }
  });
  console.log(`❤️ Trouvés: ${favItems.length}`);
  if(favItems.length===0){ alert('✅ Aucun fav de ce dressing dans tes favoris'); return; }
  favItems.forEach(({item})=>{
    item.style.outline='4px solid #0074de'; item.style.outlineOffset='2px'; item.style.position='relative';
    const b=document.createElement('div'); b.textContent='💙 DANS TES FAVS'; b.style.cssText='position:absolute;top:8px;left:8px;background:#0074de;color:white;padding:5px 10px;border-radius:20px;font-weight:bold;font-size:11px;z-index:50'; item.appendChild(b);
  });
  if(document.getElementById('vinted-dressing-panel')) document.getElementById('vinted-dressing-panel').remove();
  const panel=document.createElement('div'); panel.id='vinted-dressing-panel';
  panel.style.cssText='position:fixed;bottom:20px;right:20px;background:#1e1e1e;color:white;padding:18px;border-radius:12px;z-index:99999;width:360px;border:2px solid #0074de;font-family:sans-serif';
  panel.innerHTML=`<h3 style="margin:0 0 10px">💔 ${favItems.length} favs dans ce dressing</h3><div id="vlist" style="max-height:300px;overflow-y:auto;margin-bottom:10px"></div><div style="display:flex;gap:6px;margin-bottom:10px"><button id="vselAll" style="flex:1;padding:8px;background:#4CAF50;color:white;border:none;border-radius:6px">✅ Tout</button><button id="vdesAll" style="flex:1;padding:8px;background:#555;color:white;border:none;border-radius:6px">❌ Aucun</button></div><button id="vdel" style="width:100%;padding:12px;background:#0074de;color:white;border:none;border-radius:8px;font-weight:bold">Retirer la sélection</button><button id="vclose" style="width:100%;margin-top:8px;background:transparent;color:#888;border:none">Fermer</button>`;
  document.body.appendChild(panel);
  const vlist=panel.querySelector('#vlist'); const checks=[];
  favItems.forEach((o,i)=>{
    const title=(o.item.querySelector('[data-testid*="description-title"]')?.textContent||`Article ${i+1}`).slice(0,35);
    const row=document.createElement('label'); row.style.cssText='display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #333;font-size:12px;cursor:pointer';
    row.innerHTML=`<input type="checkbox" checked><span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${title}</span>`;
    vlist.appendChild(row); checks.push({cb:row.querySelector('input'), favBtn:o.favBtn, item:o.item});
  });
  panel.querySelector('#vselAll').onclick=()=>checks.forEach(c=>c.cb.checked=true);
  panel.querySelector('#vdesAll').onclick=()=>checks.forEach(c=>c.cb.checked=false);
  panel.querySelector('#vclose').onclick=()=>panel.remove();
  panel.querySelector('#vdel').onclick=async()=>{
    const sel=checks.filter(c=>c.cb.checked); if(!sel.length) return alert('Vide'); if(!confirm(`Retirer ${sel.length} favs?`)) return;
    for(let i=0;i<sel.length;i++){ sel[i].item.style.opacity='0.3'; sel[i].favBtn.click(); await sleep(700); }
    alert(`✅ ${sel.length} retirés`); location.reload();
  };
}

