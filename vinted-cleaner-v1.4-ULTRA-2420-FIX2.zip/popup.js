
document.getElementById('btn-sold').onclick = () => {
  chrome.tabs.query({active:true, currentWindow:true}, tabs => {
    chrome.tabs.sendMessage(tabs[0].id, {action: 'CLEAN_SOLD'});
    window.close();
  });
};
document.getElementById('btn-dressing').onclick = () => {
  chrome.tabs.query({active:true, currentWindow:true}, tabs => {
    chrome.tabs.sendMessage(tabs[0].id, {action: 'CLEAN_DRESSING'});
    window.close();
  });
};
document.getElementById('btn-both').onclick = () => {
  chrome.tabs.query({active:true, currentWindow:true}, tabs => {
    const url = tabs[0].url || '';
    if(url.includes('favourite_list') || url.includes('favoris') || url.includes('favoritos')){
      chrome.tabs.sendMessage(tabs[0].id, {action: 'CLEAN_SOLD'});
    } else {
      chrome.tabs.sendMessage(tabs[0].id, {action: 'CLEAN_DRESSING'});
    }
    window.close();
  });
};
