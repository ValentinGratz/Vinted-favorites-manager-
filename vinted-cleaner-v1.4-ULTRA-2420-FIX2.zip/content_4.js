
console.log('💖 Vinted Cleaner v1.4 ULTRA 2420 - loaded');
function injectLauncher(){
  try{
    if(!document.body) return;
    if(document.getElementById('vinted-cleaner-launcher')) return;
    const div=document.createElement('div');
    div.id='vinted-cleaner-launcher';
    div.style.cssText='position:fixed;bottom:20px;right:20px;z-index:999999;background:#111;color:white;padding:12px 16px;border-radius:12px;border:2px solid #ff4444;box-shadow:0 8px 32px rgba(0,0,0,0.6);display:flex;gap:8px;align-items:center;font-family:sans-serif';
    div.innerHTML=`<span style="font-weight:bold;font-size:13px">💖 Cleaner v1.4</span><button id="vc-sold" style="background:#ff4444;color:white;padding:8px 12px;border:none;border-radius:6px;font-weight:bold;cursor:pointer">🔴 Scan 2420</button><button id="vc-close" style="background:#222;color:#888;padding:6px 8px;border:none;border-radius:6px;cursor:pointer">✕</button>`;
    document.body.appendChild(div);
    div.querySelector('#vc-sold').onclick=()=>runUltraScan();
    div.querySelector('#vc-close').onclick=()=>div.remove();
  }catch(e){}
}
setTimeout(injectLauncher,2000);
chrome.runtime.onMessage.addListener((msg)=>{ if(msg.action==='CLEAN_SOLD') runUltraScan(); if(msg.action==='CLEAN_DRESSING') runCleanDressing(); });

async function runUltraScan(){
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  console.log('🚀 ULTRA SCAN 2420 - Démarrage');

  let bar=document.createElement('div');
  bar.id='vinted-ultra-bar';
  bar.style.cssText='position:fixed;top:0;left:0;width:100%;background:#111;color:white;padding:10px;text-align:center;z-index:9999999;font-family:sans-serif;font-size:14px;border-bottom:3px solid #ff4444';
  bar.innerHTML=`<div>📦 SCAN ULTRA en cours... <span id="ultra-count">0</span> favs chargés | <span id="ultra-sold">0</span> vendus trouvés | RAM optimisée</div><div style="height:4px;background:#333;margin-top:6px"><div id="ultra-progress" style="height:100%;width:0%;background:#ff4444;transition:width 0.3s"></div></div>`;
  try{ document.body.appendChild(bar); }catch(e){}

  let lastCount=0, stable=0, totalSoldFound=0;
  let allSoldData=[];
  const MAX_FAVS=3000;
  const STABLE_LIMIT=10;

  while(stable < STABLE_LIMIT && lastCount < MAX_FAVS){
    const items=document.querySelectorAll('[data-testid="grid-item"]');
    const currentCount=items.length;

    // Update UI
    const countEl=document.getElementById('ultra-count');
    const soldEl=document.getElementById('ultra-sold');
    const progEl=document.getElementById('ultra-progress');
    if(countEl) countEl.textContent=currentCount;
    if(progEl) progEl.style.width=`${Math.min(99, (currentCount/2420)*100)}%`;

    // Memory optimization every 200 items: remove image src of old items to avoid crash
    if(currentCount>0 && currentCount%200===0){
      console.log(`🧹 Optimisation RAM à ${currentCount} favs - suppression images anciennes`);
      const allImgs=document.querySelectorAll('[data-testid="grid-item"] img');
      // Keep only last 150 images
      for(let i=0;i<allImgs.length-150;i++){
        try{ allImgs[i].removeAttribute('src'); allImgs[i].removeAttribute('srcset'); }catch(e){}
      }
    }

    // Detect sold on the fly
    items.forEach((gridItem, idx)=>{
      if(gridItem.dataset.scanned) return;
      gridItem.dataset.scanned="1";
      try{
        const statusText=gridItem.querySelector('[data-testid*="status-text"]');
        if(statusText && ['vendu','vendido','sold','venduto','verkauft'].includes(statusText.textContent.trim().toLowerCase())){
          const titleEl=gridItem.querySelector('[data-testid*="description-title"]');
          const title=titleEl?titleEl.textContent.trim().substring(0,40):`Article ${idx+1}`;
          const favBtn=gridItem.querySelector('button[data-testid*="favourite"]')||gridItem.querySelector('button[data-testid*="favorite"]')||gridItem.querySelector('button[data-testid*="item-favourite-button"]');
          if(favBtn){
            allSoldData.push({title,favBtn,gridItem,idx});
            totalSoldFound++;
            if(soldEl) soldEl.textContent=totalSoldFound;
            // Light outline only for sold
            try{ gridItem.style.outline='3px solid #ff4444'; }catch(e){}
          }
        }
      }catch(e){}
    });

    // Scroll
    if(items.length>0){
      try{ items[items.length-1].scrollIntoView({block:'end'}); }catch(e){}
      await sleep(200);
      try{ window.scrollBy(0,300); }catch(e){}
    }else{
      try{ window.scrollTo(0,document.body.scrollHeight); }catch(e){}
    }

    await sleep(1100);

    const newCount=document.querySelectorAll('[data-testid="grid-item"]').length;
    if(newCount===lastCount){ stable++; console.log(`⏳ Stable ${stable}/${STABLE_LIMIT} - ${newCount} favs, ${totalSoldFound} vendus`); }
    else { stable=0; console.log(`📦 ${newCount} favs (${totalSoldFound} vendus)`); }
    lastCount=newCount;

    if(newCount>=MAX_FAVS) break;
  }

  const progEl=document.getElementById('ultra-progress');
  if(progEl) progEl.style.width='100%';
  const barEl=document.getElementById('vinted-ultra-bar');
  if(barEl) barEl.innerHTML=`✅ Scan fini: ${lastCount} favs parcourus, ${allSoldData.length} vendus trouvés | Tu peux nettoyer maintenant`;

  console.log(`✅ FIN SCAN: ${lastCount} favs, ${allSoldData.length} vendus`);

  if(allSoldData.length===0){
    alert(`✅ Aucun vendu sur ${lastCount} favs scannés ! Tu es clean sur tout ton compte.`);
    if(barEl) setTimeout(()=>barEl.remove(),4000);
    return;
  }

  // Panel
  if(document.getElementById('vinted-control-panel')) document.getElementById('vinted-control-panel').remove();
  const panel=document.createElement('div');
  panel.id='vinted-control-panel';
  panel.style.cssText=`position:fixed;bottom:20px;right:20px;background:#1e1e1e;color:white;padding:16px;border-radius:12px;z-index:9999999;width:380px;max-height:80vh;display:flex;flex-direction:column;border:2px solid #ff4444;font-family:sans-serif;box-shadow:0 8px 32px rgba(0,0,0,0.6)`;
  panel.innerHTML=`
    <h3 style="margin:0 0 8px;font-size:14px">🔴 ${allSoldData.length} vendus trouvés sur ${lastCount} favs</h3>
    <div style="font-size:11px;color:#aaa;margin-bottom:8px">Scan complet de tes 2420 favs réussi sans crash !</div>
    <div id="list" style="flex:1;overflow-y:auto;max-height:35vh;border:1px solid #333;border-radius:6px;padding:4px;margin-bottom:10px"></div>
    <div style="display:flex;gap:6px;margin-bottom:8px">
      <button id="selAll" style="flex:1;padding:8px;background:#4CAF50;color:white;border:none;border-radius:6px;font-weight:bold;cursor:pointer">✅ Tout</button>
      <button id="desAll" style="flex:1;padding:8px;background:#555;color:white;border:none;border-radius:6px;cursor:pointer">❌ Aucun</button>
    </div>
    <button id="delBtn" style="width:100%;padding:12px;background:#ff4444;color:white;border:none;border-radius:8px;font-weight:bold;cursor:pointer">🗑️ Supprimer les ${allSoldData.length} vendus</button>
    <button id="close" style="margin-top:6px;width:100%;background:transparent;color:#888;border:none;cursor:pointer">Fermer</button>
  `;
  try{ document.body.appendChild(panel); }catch(e){}
  const listDiv=panel.querySelector('#list');
  allSoldData.forEach((d,i)=>{
    const row=document.createElement('label');
    row.style.cssText='display:flex;align-items:center;gap:6px;padding:5px 0;border-bottom:1px solid #222;font-size:12px;cursor:pointer';
    row.innerHTML=`<input type="checkbox" checked data-i="${i}" style="width:14px;height:14px"><span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${d.title}</span>`;
    listDiv.appendChild(row);
  });
  panel.querySelector('#selAll').onclick=()=>listDiv.querySelectorAll('input').forEach(c=>c.checked=true);
  panel.querySelector('#desAll').onclick=()=>listDiv.querySelectorAll('input').forEach(c=>c.checked=false);
  panel.querySelector('#close').onclick=()=>{ panel.remove(); const b=document.getElementById('vinted-ultra-bar'); if(b) b.remove(); };
  panel.querySelector('#delBtn').onclick=async()=>{
    const checks=[...listDiv.querySelectorAll('input:checked')].map(c=>allSoldData[parseInt(c.dataset.i)]);
    if(!checks.length) return;
    if(!confirm(`Supprimer ${checks.length} vendus ?`)) return;
    let ok=0;
    for(let d of checks){
      try{ d.favBtn.click(); d.gridItem.style.opacity='0.2'; ok++; await sleep(500+Math.random()*300); }catch(e){}
    }
    alert(`✅ ${ok} supprimés sur tes 2420 favs !`);
    location.reload();
  };
  try{ window.scrollTo(0,0); }catch(e){}
}

async function runCleanDressing(){
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  let lastHeight=0,noChange=0;
  for(let i=0;i<60 && noChange<5;i++){
    try{ window.scrollTo(0, document.body.scrollHeight); }catch(e){}
    await sleep(1300);
    const h=document.body.scrollHeight; if(h===lastHeight){noChange++;} else {noChange=0;} lastHeight=h;
  }
  const allItems=document.querySelectorAll('[data-testid="grid-item"]'); const favItems=[];
  allItems.forEach(item=>{
    const favBtn=item.querySelector('button[data-testid="favourite-button"]')||item.querySelector('button[data-testid="favorite-button"]')||item.querySelector('button[data-testid="item-favourite-button"]')||item.querySelector('button[aria-label*="favoris"]');
    if(!favBtn) return;
    const ariaLabel=(favBtn.getAttribute('aria-label')||'').toLowerCase(); const pressed=favBtn.getAttribute('aria-pressed');
    const isFav=ariaLabel.includes('retirer')||ariaLabel.includes('remove')||pressed==='true';
    if(isFav){ favItems.push({item,favBtn}); }
  });
  if(favItems.length===0){ alert('✅ Aucun fav de ce dressing'); return; }
  if(document.getElementById('vinted-dressing-panel')) document.getElementById('vinted-dressing-panel').remove();
  const panel=document.createElement('div'); panel.id='vinted-dressing-panel';
  panel.style.cssText='position:fixed;bottom:20px;right:20px;background:#1e1e1e;color:white;padding:16px;border-radius:12px;z-index:9999999;width:360px;border:2px solid #0074de;font-family:sans-serif';
  panel.innerHTML=`<h3 style="margin:0 0 10px">💙 ${favItems.length} favs</h3><div id="vlist" style="max-height:300px;overflow-y:auto;margin-bottom:10px;border:1px solid #333;border-radius:6px;padding:4px"></div><button id="vdel" style="width:100%;padding:12px;background:#0074de;color:white;border:none;border-radius:8px;font-weight:bold;cursor:pointer">Retirer</button><button id="vclose" style="width:100%;margin-top:6px;background:transparent;color:#888;border:none;cursor:pointer">Fermer</button>`;
  try{ document.body.appendChild(panel); }catch(e){ return; }
  const vlist=panel.querySelector('#vlist'); const checks=[];
  favItems.forEach((o,i)=>{
    const title=(o.item.querySelector('[data-testid*="description-title"]')?.textContent||`Article ${i+1}`).slice(0,35);
    const row=document.createElement('label'); row.style.cssText='display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #333;font-size:12px;cursor:pointer';
    row.innerHTML=`<input type="checkbox" checked><span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${title}</span>`;
    vlist.appendChild(row); checks.push({cb:row.querySelector('input'),favBtn:o.favBtn,item:o.item});
  });
  panel.querySelector('#vclose').onclick=()=>panel.remove();
  panel.querySelector('#vdel').onclick=async()=>{
    const sel=checks.filter(c=>c.cb.checked); if(!sel.length) return; if(!confirm(`Retirer ${sel.length}?`)) return;
    for(let i=0;i<sel.length;i++){ try{ sel[i].item.style.opacity='0.3'; sel[i].favBtn.click(); await sleep(600); }catch(e){} }
    alert(`✅ ${sel.length} retirés`); location.reload();
  };
}
