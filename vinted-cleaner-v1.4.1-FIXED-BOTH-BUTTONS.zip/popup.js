
document.getElementById('cleanSold')?.addEventListener('click', async()=>{
  let [tab]=await chrome.tabs.query({active:true, currentWindow:true});
  chrome.tabs.sendMessage(tab.id, {action:'CLEAN_SOLD'});
});
document.getElementById('cleanDressing')?.addEventListener('click', async()=>{
  let [tab]=await chrome.tabs.query({active:true, currentWindow:true});
  chrome.tabs.sendMessage(tab.id, {action:'CLEAN_DRESSING'});
});
